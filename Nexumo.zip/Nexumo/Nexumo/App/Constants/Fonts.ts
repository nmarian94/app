const Fonts = {
    bold30: {
        fontSize: 30,
        fontFamily: 'Poppins-Bold'
    },
    semiBold30: {
        fontSize: 30,
        fontFamily: 'Poppins-SemiBold'
    },
    bold28: {
        fontSize: 28,
        fontFamily: 'Poppins-Bold'
    },
    semiBold28: {
        fontSize: 28,
        fontFamily: 'Poppins-SemiBold'
    },
    bold25: {
        fontSize: 25,
        fontFamily: 'Poppins-Bold'
    },
    semiBold25: {
        fontSize: 25,
        fontFamily: 'Poppins-SemiBold'
    },
    semiBold22: {
        fontSize: 22,
        fontFamily: 'Poppins-SemiBold'
    },
    bold20: {
        fontSize: 20,
        fontFamily: 'Poppins-Bold'
    },
    semiBold20: {
        fontSize: 20,
        fontFamily: 'Poppins-SemiBold'
    },
    medium18: {
        fontSize: 18,
        fontFamily: 'Poppins-Medium'
    },
    semiBold18: {
        fontSize: 18,
        fontFamily: 'Poppins-SemiBold'
    },
    bold18: {
        fontSize: 18,
        fontFamily: 'Poppins-Bold'
    },
    regular18: {
        fontSize: 18,
        fontFamily: 'Poppins-Regular'
    },
    semiBold17: {
        fontSize: 17,
        fontFamily: 'Poppins-SemiBold'
    },
    medium17: {
        fontSize: 17,
        fontFamily: 'Poppins-Medium'
    },
    regular17: {
        fontSize: 17,
        fontFamily: 'Poppins-Regular'
    },
    bold16: {
        fontSize: 16,
        fontFamily: 'Poppins-Bold'
    },
    semiBold16: {
        fontSize: 16,
        fontFamily: 'Poppins-SemiBold'
    },
    medium16: {
        fontSize: 16,
        fontFamily: 'Poppins-Medium'
    },
    regular16: {
        fontSize: 16,
        fontFamily: 'Poppins-Regular'
    },
    regular15: {
        fontSize: 15,
        fontFamily: 'Poppins-Regular'
    },
    medium15: {
        fontSize: 15,
        fontFamily: 'Poppins-Medium'
    },
    semiBold15: {
        fontSize: 15,
        fontFamily: 'Poppins-SemiBold'
    },
    bold15: {
        fontSize: 15,
        fontFamily: 'Poppins-Bold'
    },
    bold14: {
        fontSize: 14,
        fontFamily: 'Poppins-Bold'
    },
    medium14: {
        fontSize: 14,
        fontFamily: 'Poppins-Medium'
    },
    semiBold14: {
        fontSize: 14,
        fontFamily: 'Poppins-SemiBold'
    },
    regular14: {
        fontSize: 14,
        fontFamily: 'Poppins-Regular'
    },
    regular13: {
        fontSize: 13,
        fontFamily: 'Poppins-Regular'
    },
    medium12: {
        fontSize: 12,
        fontFamily: 'Poppins-Medium'
    },
    regular12: {
        fontSize: 12,
        fontFamily: 'Poppins-Regular'
    },

    nunitoBold20: {
        fontSize: 20,
        fontFamily: 'Nunito-Bold'
    },
    nunitoSemiBold20: {
        fontSize: 20,
        fontFamily: 'Nunito-SemiBold'
    },
    nunitoSemiBold18: {
        fontSize: 18,
        fontFamily: 'Nunito-SemiBold'
    },
    nunitoMedium18: {
        fontSize: 18,
        fontFamily: 'Nunito-Medium'
    },
    nunitoRegular14: {
        fontSize: 14,
        fontFamily: 'Nunito-Regular'
    }
}

export default Fonts;