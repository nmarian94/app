const Colors = {
  BLUE: '#2381FD',
  LIGHT_BLUE: '#41B5FE',
  BLACK: '#222222',
  WHITE: '#FFFFFF',
  GREY: '#7F7F7F',
  LIGHT_GREY: '#B5B5B5',
  GREY100: '#E6E6E6',
  RED: '#E8504D'
};

export default Colors;
