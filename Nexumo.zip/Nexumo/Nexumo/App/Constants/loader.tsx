import React from 'react';
import { StyleSheet, View, Modal, ActivityIndicator, Platform } from 'react-native';
import { Colors } from '.';

const isIos = Platform.OS === "ios"

const Loader = (props: any) => {
    const { loading } = props;
    return (
        <Modal
            transparent={true}
            animationType={'none'}
            visible={loading}
            onRequestClose={() => {
                console.log('close modal');
            }}>
            <View style={styles.modalBackground}>
                <View style={isIos ? styles.activityIndicatorWrapperIos : styles.activityIndicatorWrapper}>
                    <ActivityIndicator
                        animating={true}
                        color={Colors.BLUE}
                        size="large"
                    />
                </View>
            </View>
        </Modal>
    );
};
export default Loader;


const styles = StyleSheet.create({
    modalBackground: {
        flex: 1,
        alignItems: 'center',
        backgroundColor: '#00000040',
        justifyContent: 'center',
    },
    activityIndicatorWrapperIos: {
        alignItems: 'center',
        backgroundColor: 'white',
        justifyContent: 'center',
        padding: 5,
        borderRadius: 90,
        paddingRight: 2,
        paddingBottom: 2
    },
    activityIndicatorWrapper: {
        alignItems: 'center',
        backgroundColor: 'white',
        justifyContent: 'center',
        padding: 5,
        borderRadius: 90
    },
});
