import React, { useEffect, useState } from "react";
import { DrawerContentScrollView, createDrawerNavigator } from "@react-navigation/drawer";
import BottomTab from "./HomeNavigation";
import { Image, StyleSheet, Text, TouchableOpacity, View, useWindowDimensions } from "react-native";
import CloseIcon from "../Assets/svg/close.svg"
import ArrowRightIcon from "../Assets/svg/arrow-right-blue.svg"
import CategoryIcon from "../Assets/svg/category.svg"
import ChartsIcon from "../Assets/svg/charts.svg"
import RegularPaymentsIcon from "../Assets/svg/regular-payments.svg"
import ReminderBellIcon from "../Assets/svg/remainder-bell.svg"
import SettingsIcon from "../Assets/svg/settings.svg"
import SyncIcon from "../Assets/svg/sync.svg"
import TransactionIcon from "../Assets/svg/transaction.svg"
import WalletIcon from "../Assets/svg/wallet.svg"
import CashIcon from "../Assets/svg/cash.svg"
import PlusIcon from "../Assets/svg/plus.svg"
import CommonStyles from "../Screens/styles/CommonStyles";
import SpaceStyles from "../Screens/styles/SpaceStyles";
import AccountsScreen from "../Screens/Account/AccountsScreen";
import AddNewAccountScreen from "../Screens/Account/AddNewAccountScreen";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import CategoriesScreen from "../Screens/Categories/CategoriesScreen";
import AddCategoriesScreen from "../Screens/Categories/AddCategoriesScreen";
import SettingsScreen from "../Screens/Settings/SettingsScreen";
import { useTranslation } from "react-i18next";
import { Colors, Fonts } from "../Constants";

const Drawer = createDrawerNavigator();
const Stack = createNativeStackNavigator();

export default () => {
    return (
        <Drawer.Navigator
            screenOptions={{
                headerShown: false,
                drawerStyle: { width: '80%' },
            }}
            drawerContent={(props) => <CustomDrawerComp {...props} />}>
            <Drawer.Screen name="BottomTab" component={BottomTab} />
            <Drawer.Screen name="AccountsNavigation" component={AccountsNavigation} />
            <Drawer.Screen name="AccountsScreen" component={AccountsScreen} />
            <Drawer.Screen name="AddNewAccountScreen" component={AddNewAccountScreen} />
            <Drawer.Screen name="CategoriesNavigation" component={CategoriesNavigation} />
            <Drawer.Screen name="SettingsScreen" component={SettingsScreen} />
        </Drawer.Navigator>
    );
};

function AccountsNavigation() {
    return (
        <Stack.Navigator screenOptions={{ headerShown: false }}>
            <Stack.Screen name="AccountsScreen" component={AccountsScreen} />
            <Stack.Screen name="AddNewAccountScreen" component={AddNewAccountScreen} />
        </Stack.Navigator>
    );
}

function CategoriesNavigation() {
    return (
        <Stack.Navigator screenOptions={{ headerShown: false }}>
            <Stack.Screen name="CategoriesScreen" component={CategoriesScreen} />
            <Stack.Screen name="AddCategoriesScreen" component={AddCategoriesScreen} />
        </Stack.Navigator>
    );
}

export const CustomDrawerComp = (props: any) => {
    const { t } = useTranslation();
    const { navigation } = props;
    const [name, setName] = useState('')
    const [email, setEmail] = useState('')

    return (
        <DrawerContentScrollView {...props}>
            <View>
                <TouchableOpacity onPress={() => navigation.closeDrawer()}>
                    <CloseIcon style={{ margin: 10, alignSelf: 'flex-end' }} />
                </TouchableOpacity>

                <View style={styles.profile}>
                    <Image
                        source={require('../Assets/images/profile.png')}
                        style={styles.profileImage} />
                    <View>
                        <Text style={{ color: Colors.BLACK, ...Fonts.nunitoBold20 }}>Callie Mosley</Text>
                        <Text style={{ color: Colors.BLACK, ...Fonts.nunitoMedium18 }}>calliemosley@gmail.com</Text>
                    </View>
                </View>

                <View style={[SpaceStyles.flexRow, { marginTop: 10 }]}>
                    <View style={styles.accountView}>
                        <View style={[SpaceStyles.flexRow, styles.accountViewSpace]}>
                            <View style={[CommonStyles.itemIcon, { backgroundColor: Colors.BLUE }]}>
                                <CashIcon />
                            </View>
                            <Text style={{ paddingLeft: 10, color: Colors.BLACK, ...Fonts.semiBold18 }}>David</Text>
                        </View>
                        <View style={[styles.line, { marginHorizontal: 0 }]} />
                        <View style={[SpaceStyles.flexRow, styles.accountViewSpace, { justifyContent: 'space-between' }]}>
                            <Text style={{ color: Colors.BLACK, ...Fonts.medium16 }}>{t('balance')}:</Text>
                            <Text style={{ color: Colors.BLACK, ...Fonts.semiBold18 }}>$1200</Text>
                        </View>
                    </View>
                    <TouchableOpacity
                        onPress={() => navigation.navigate('AddNewAccountScreen')}
                        style={styles.plusButton}>
                        <PlusIcon height={20} width={20} />
                    </TouchableOpacity>
                </View>
                <TouchableOpacity
                    onPress={() => navigation.navigate('AccountsNavigation')}
                    style={styles.drawerItem}>
                    <WalletIcon />
                    <View style={styles.drawerTextView}>
                        <Text style={styles.drawerItemText}>{t('accounts')}</Text>
                    </View>
                    <ArrowRightIcon />
                </TouchableOpacity>
                <View style={styles.line} />
                <TouchableOpacity
                    onPress={() => navigation.navigate('CategoriesNavigation')}
                    style={styles.drawerItem}>
                    <CategoryIcon />
                    <View style={styles.drawerTextView}>
                        <Text style={styles.drawerItemText}>{t('categories')}</Text>
                    </View>
                    <ArrowRightIcon />
                </TouchableOpacity>
                <View style={styles.line} />
                <TouchableOpacity style={styles.drawerItem}>
                    <ReminderBellIcon />
                    <View style={styles.drawerTextView}>
                        <Text style={styles.drawerItemText}>{t('reminder')}</Text>
                    </View>
                </TouchableOpacity>
                <View style={styles.line} />
                <TouchableOpacity style={styles.drawerItem}>
                    <RegularPaymentsIcon />
                    <View style={styles.drawerTextView}>
                        <Text style={styles.drawerItemText}>{t('regularpayments')}</Text>
                    </View>
                </TouchableOpacity>
                <View style={styles.line} />
                <TouchableOpacity style={styles.drawerItem}>
                    <TransactionIcon />
                    <View style={styles.drawerTextView}>
                        <Text style={styles.drawerItemText}>{t('exporttransaction')}</Text>
                    </View>
                </TouchableOpacity>
                <View style={styles.line} />
                <TouchableOpacity style={styles.drawerItem}>
                    <TransactionIcon />
                    <View style={styles.drawerTextView}>
                        <Text style={styles.drawerItemText}>{t('startedtransaction')}</Text>
                    </View>
                </TouchableOpacity>
                <View style={styles.line} />
                <TouchableOpacity style={styles.drawerItem}>
                    <SyncIcon />
                    <View style={styles.drawerTextView}>
                        <Text style={styles.drawerItemText}>{t('syncbackup')}</Text>
                    </View>
                </TouchableOpacity>
                <View style={styles.line} />
                <TouchableOpacity
                    onPress={() => navigation.navigate('SettingsScreen')}
                    style={styles.drawerItem}>
                    <SettingsIcon />
                    <View style={styles.drawerTextView}>
                        <Text style={styles.drawerItemText}>{t('settings')}</Text>
                    </View>
                    <ArrowRightIcon />
                </TouchableOpacity>
                <View style={styles.line} />
            </View>
        </DrawerContentScrollView>
    );
};

const styles = StyleSheet.create({
    profile: {
        paddingHorizontal: 10, 
        paddingBottom: 10, 
        flexDirection: 'row', 
        borderBottomWidth: 1, 
        borderColor: Colors.LIGHT_GREY
    },
    profileImage: {
        height: 60, 
        width: 60, 
        borderRadius: 50, 
        marginRight: 10
    },
    drawerItem: {
        margin: 16, 
        flexDirection: 'row', 
        alignItems: 'center'
    },
    drawerTextView: {
        flex: 1, 
        paddingHorizontal: 10
    },
    drawerItemText: {
        color: Colors.BLACK, 
        ...Fonts.nunitoSemiBold18
    },
    accountView: {
        flex: 1,
        marginHorizontal: 10,
        borderRadius: 20,
        backgroundColor: Colors.WHITE,
        shadowColor: "#000",
        shadowOffset: {
            width: 0,
            height: 1,
        },
        shadowOpacity: 0.20,
        shadowRadius: 1.41,
        elevation: 2,
    },
    accountViewSpace: {
        paddingHorizontal: 12, 
        paddingVertical: 10
    },
    plusButton: {
        height: 108, 
        width: 70, 
        backgroundColor: Colors.BLUE, 
        marginRight: 16, 
        borderRadius: 20, 
        alignItems: 'center', 
        justifyContent: 'center'
    },
    line: {
        marginHorizontal: 16, 
        borderBottomWidth: 0.5, 
        borderColor: Colors.LIGHT_GREY
    }
})