import * as React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import SplashScreen from '../Screens/Auth/SplashScreen';
import HomeNavigation from './HomeNavigation';
import WelcomeScreen from '../Screens/Auth/WelcomeScreen';
import SocialLoginScreen from '../Screens/Auth/SocialLoginScreen';
import RegisterScreen from '../Screens/Auth/RegisterScreen';
import LoginScreen from '../Screens/Auth/LoginScreen';
import BottomTab from './HomeNavigation';
import DrawerNavigation from './DrawerNavigation';

const Stack = createNativeStackNavigator();

function StackNavigation() {
    return (
        <Stack.Navigator screenOptions={{ headerShown: false }}>
            <Stack.Screen name="SplashScreen" component={SplashScreen} />
            <Stack.Screen name="WelcomeScreen" component={WelcomeScreen} />
            <Stack.Screen name="SocialLoginScreen" component={SocialLoginScreen} />
            <Stack.Screen name="RegisterScreen" component={RegisterScreen} />
            <Stack.Screen name="LoginScreen" component={LoginScreen} />
            <Stack.Screen name="DrawerNavigation" component={DrawerNavigation} />
        </Stack.Navigator>
    );
}

export default StackNavigation;
