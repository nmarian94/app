import React from 'react';
import { StyleSheet, View, TouchableOpacity, Text } from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import Home from "../Assets/svg/home.svg";
import Stats from "../Assets/svg/stats.svg";
import Budget from "../Assets/svg/budget.svg";
import Notification from "../Assets/svg/notification.svg";
import HomeSelected from "../Assets/svg/home-selected.svg";
import StatsSelected from "../Assets/svg/stats-selected.svg";
import BudgetSelected from "../Assets/svg/budget-selected.svg";
import NotificationSelected from "../Assets/svg/notification-selected.svg";
import { useTranslation } from 'react-i18next';
import { Colors } from '../Constants';

function TabBar(props: any) {
    const { t } = useTranslation();
    const insets = useSafeAreaInsets();
    const { descriptors, navigation, state } = props
    const focusedOptions = descriptors[state.routes[state.index].key].options;

    const tabBarConfig = [{
        key: 1,
        icon: 1,
        name: "HomeNavigation",
        tabName: t('home')
    }, {
        key: 2,
        icon: 2,
        name: "BudgetNavigation",
        tabName: t('budget')
    }, {
        key: 3,
        icon: 3,
        name: "StatsScreen",
        tabName: t('stats')
    }, {
        key: 4,
        icon: 4,
        name: "NotificationScreen",
        tabName: t('notification')
    }]

    if (focusedOptions.tabBarVisible === false) {
        return null;
    }

    return (
        <>
            <LinearGradient
                colors={[Colors.BLUE, Colors.LIGHT_BLUE]}
                start={{ x: 0, y: 1 }} end={{ x: 0, y: 0 }}
                style={styles.container}>
                <View style={styles.rowContainer}>
                    {
                        tabBarConfig.map((route, index) => {
                            const isFocused = state.index === index;

                            const onPress = () => {
                                const event = navigation.emit({
                                    type: 'tabPress',
                                    target: route.key,
                                    canPreventDefault: true,
                                });

                                if (!isFocused && !event.defaultPrevented) {
                                    navigation.navigate(route.name);
                                }
                            };

                            return (
                                <TouchableOpacity
                                    key={index}
                                    activeOpacity={0.9}
                                    onPress={onPress}
                                    style={styles.selectedTab}
                                >
                                    <View style={[{ height: 10, width: 3 }, isFocused && { backgroundColor: Colors.WHITE }]}></View>
                                    <View style={[styles.iconView, isFocused && { backgroundColor: Colors.WHITE, borderRadius: 20 }]}>
                                        {route?.icon == 1 && <>
                                            {isFocused ? <HomeSelected height={28} width={28} /> : <Home height={28} width={28} />}
                                        </>}
                                        {route?.icon == 2 && <>
                                            {isFocused ? <BudgetSelected height={28} width={28} /> : <Budget height={28} width={28} />}
                                        </>}
                                        {route?.icon == 3 && <>
                                            {isFocused ? <StatsSelected height={28} width={28} /> : <Stats height={28} width={28} />}
                                        </>}
                                        {route?.icon == 4 && <>
                                            {isFocused ? <NotificationSelected height={28} width={28} /> : <Notification height={28} width={28} />}
                                        </>}
                                    </View>
                                    <Text style={styles.textTitle}>{route?.tabName}</Text>
                                </TouchableOpacity>
                            )
                        })
                    }
                </View>
                <View style={{ height: insets.bottom }} />
            </LinearGradient>
        </>
    )
}

export default TabBar

const styles = StyleSheet.create({
    container: {
        shadowColor: "#000",
        shadowOffset: {
            width: 0,
            height: 2,
        },
        shadowOpacity: 0.25,
        shadowRadius: 3.84,
        elevation: 5,
    },
    rowContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-evenly'
    },
    iconView: {
        height: 34,
        width: 34,
        alignItems: 'center',
        justifyContent: 'center'
    },
    selectedTab: {
        paddingTop: 2,
        paddingBottom: 6,
        paddingHorizontal: 8,
        alignItems: 'center',
        flexDirection: 'column',
        justifyContent: 'center',
        height: 60
    },
    textTitle: {
        fontSize: 13,
        fontFamily: 'Poppins-Medium',
        color: Colors.WHITE,
        marginTop: 2
        // marginTop: (Constants.BaseStyle.DEVICE_HEIGHT / 100) * 0.7,
    },
})
