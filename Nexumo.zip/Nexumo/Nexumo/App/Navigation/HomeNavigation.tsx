import * as React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import TabBar from './TabBar';
import HomeScreen from '../Screens/Home/HomeScreen';
import BudgetScreen from '../Screens/Budget/BudgetScreen';
import StatsScreen from '../Screens/Stats/StatsScreen';
import NotificationScreen from '../Screens/Notification/NotificationScreen';
import AddDataScreen from '../Screens/AddData';
import TransactionsScreen from '../Screens/Transactions/TransactionsScreen';
import AllTransactionsScreen from '../Screens/Transactions/AllTransactionsScreen';
import AddCategoriesScreen from '../Screens/Categories/AddCategoriesScreen';

const Stack = createNativeStackNavigator();
const Tab = createBottomTabNavigator();

function HomeNavigation() {
    return (
        <Stack.Navigator screenOptions={{ headerShown: false }}>
            <Stack.Screen name="HomeScreen" component={HomeScreen} />
            <Stack.Screen name="AddDataScreen" component={AddDataScreen} />
            <Stack.Screen name="AddCategoriesScreen" component={AddCategoriesScreen} />
        </Stack.Navigator>
    );
}

function BudgetNavigation() {
    return (
        <Stack.Navigator screenOptions={{ headerShown: false }}>
            <Stack.Screen name="BudgetScreen" component={BudgetScreen} />
            <Stack.Screen name="TransactionsScreen" component={TransactionsScreen} />
            <Stack.Screen name="AllTransactionsScreen" component={AllTransactionsScreen} />
        </Stack.Navigator>
    );
}

function BottomTab() {
    return (
        <Tab.Navigator
            tabBar={props => <TabBar {...props} />}
            screenOptions={{ headerShown: false, tabBarHideOnKeyboard: true }}
        >
            <Tab.Screen name="HomeNavigation" component={HomeNavigation} />
            <Tab.Screen name="BudgetNavigation" component={BudgetNavigation} />
            <Tab.Screen name="StatsScreen" component={StatsScreen} />
            <Tab.Screen name="NotificationScreen" component={NotificationScreen} />
        </Tab.Navigator>
    );
}

export default BottomTab;
