import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import HomeNavigation from './HomeNavigation';
import StackNavigation from './StackNavigation';

const Stack = createNativeStackNavigator();

const MainRoute = () => (
    <Stack.Navigator
        initialRouteName={"StackNavigation"}
        screenOptions={{
            headerShown: false,
        }} >
        <Stack.Screen name="StackNavigation" component={StackNavigation} />
        <Stack.Screen name="HomeNavigation" component={HomeNavigation} />
    </Stack.Navigator>
);

export default MainRoute;
