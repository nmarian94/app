import React, { useEffect, useState } from "react";
import { SafeAreaView, ScrollView, StyleSheet, Text, TouchableOpacity, View } from "react-native";
import CommonStyles from "../styles/CommonStyles";
import { useNavigation } from "@react-navigation/native";
import CustomAppBar from "../../Components/CustomAppBar";
import IconButton from "../../Components/IconButton";
import BackIcon from "../../Assets/svg/back-arrow-white.svg";
import CashIcon from "../../Assets/svg/cash.svg"
import WalletIcon from "../../Assets/svg/wallet-white.svg"
import HomeIcon from "../../Assets/svg/home-white.svg"
import CardIcon from "../../Assets/svg/card.svg"
import ArrowRightIcon from "../../Assets/svg/arrow-right-blue.svg"
import PlusIcon from "../../Assets/svg/plus.svg"
import CloseIcon from "../../Assets/svg/close.svg";
import { Colors, Fonts } from "../../Constants";
import SpaceStyles from "../styles/SpaceStyles";
import LinearGradient from "react-native-linear-gradient";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useTranslation } from "react-i18next";
import Loader from "../../Constants/loader";
import Modal from "react-native-modal";
import CustomButton from "../../Components/CustomButton";

const AccountsScreen = () => {
    const { t } = useTranslation();
    const insets = useSafeAreaInsets();
    const navigation = useNavigation();
    const [loading, setLoading] = useState(false)
    const [accounts, setAccounts] = useState([])
    const [isVisible, setIsVisible] = useState(false)
    const [selectedData, setSelectedData] = useState()

    const AppBar = () => {
        return (
            <CustomAppBar>
                <IconButton onPress={() => navigation.goBack()}>
                    <BackIcon />
                </IconButton>
                <View style={styles.header}>
                    <Text style={styles.headerTitle}>{t('accounts')}</Text>
                </View>
                <View style={{ width: 50 }} />
            </CustomAppBar>
        )
    }

    return (
        <View style={CommonStyles.mainContainer}>
            <Loader loading={loading} />
            <SafeAreaView style={{ backgroundColor: Colors.LIGHT_BLUE }} />
            <AppBar />

            <ScrollView>
                <View style={{ paddingVertical: 16, paddingHorizontal: 6 }}>
                    <View style={styles.accountView}>
                        <View style={[SpaceStyles.flexRow, styles.accountViewSpace]}>
                            <View style={[CommonStyles.itemIcon, { backgroundColor: Colors.BLUE }]}>
                                <WalletIcon />
                            </View>
                            <Text style={styles.accountName}>John</Text>
                            <ArrowRightIcon />
                        </View>
                        <View style={[styles.line, { marginHorizontal: 0 }]} />
                        <View style={[SpaceStyles.flexRow, styles.accountViewSpace, { justifyContent: 'space-between' }]}>
                            <Text style={{ color: Colors.BLACK, ...Fonts.medium16 }}>{t('balance')}:</Text>
                            <Text style={{ color: Colors.BLACK, ...Fonts.semiBold18 }}>$110</Text>
                        </View>
                    </View>
                    <View style={styles.accountView}>
                        <View style={[SpaceStyles.flexRow, styles.accountViewSpace]}>
                            <View style={[CommonStyles.itemIcon, { backgroundColor: Colors.BLUE }]}>
                                <HomeIcon />
                            </View>
                            <Text style={styles.accountName}>Cash</Text>
                            <ArrowRightIcon />
                        </View>
                        <View style={[styles.line, { marginHorizontal: 0 }]} />
                        <View style={[SpaceStyles.flexRow, styles.accountViewSpace, { justifyContent: 'space-between' }]}>
                            <Text style={{ color: Colors.BLACK, ...Fonts.medium16 }}>{t('balance')}:</Text>
                            <Text style={{ color: Colors.BLACK, ...Fonts.semiBold18 }}>$1000</Text>
                        </View>
                    </View>
                    <View style={styles.accountView}>
                        <View style={[SpaceStyles.flexRow, styles.accountViewSpace]}>
                            <View style={[CommonStyles.itemIcon, { backgroundColor: Colors.BLUE }]}>
                                <CardIcon />
                            </View>
                            <Text style={styles.accountName}>Ankur</Text>
                            <ArrowRightIcon />
                        </View>
                        <View style={[styles.line, { marginHorizontal: 0 }]} />
                        <View style={[SpaceStyles.flexRow, styles.accountViewSpace, { justifyContent: 'space-between' }]}>
                            <Text style={{ color: Colors.BLACK, ...Fonts.medium16 }}>{t('balance')}:</Text>
                            <Text style={{ color: Colors.BLACK, ...Fonts.semiBold18 }}>$90</Text>
                        </View>
                    </View>
                    <View style={styles.accountView}>
                        <View style={[SpaceStyles.flexRow, styles.accountViewSpace]}>
                            <View style={[CommonStyles.itemIcon, { backgroundColor: Colors.BLUE }]}>
                                <CashIcon />
                            </View>
                            <Text style={styles.accountName}>David</Text>
                            <ArrowRightIcon />
                        </View>
                        <View style={[styles.line, { marginHorizontal: 0 }]} />
                        <View style={[SpaceStyles.flexRow, styles.accountViewSpace, { justifyContent: 'space-between' }]}>
                            <Text style={{ color: Colors.BLACK, ...Fonts.medium16 }}>{t('balance')}:</Text>
                            <Text style={{ color: Colors.BLACK, ...Fonts.semiBold18 }}>$1200</Text>
                        </View>
                    </View>
                </View>
            </ScrollView>

            <Modal
                style={{ margin: 0 }}
                animationIn='zoomIn'
                animationOut='zoomOut'
                backdropTransitionOutTiming={0}
                backdropTransitionInTiming={0}
                onBackdropPress={() => setIsVisible(false)}
                onBackButtonPress={() => setIsVisible(false)}
                avoidKeyboard={true}
                isVisible={isVisible}>
                <View style={CommonStyles.modalMainView}>
                    <View style={CommonStyles.modalCell}>
                        <Text style={{ color: Colors.BLACK, ...Fonts.semiBold20 }}>{t('deleteaccount')}</Text>
                        <TouchableOpacity onPress={() => setIsVisible(false)}>
                            <CloseIcon />
                        </TouchableOpacity>
                    </View>
                    <View style={{ borderWidth: 0.5, borderColor: Colors.LIGHT_GREY, width: '100%' }} />
                    <View style={{ padding: 20, width: '100%' }}>
                        <View style={SpaceStyles.flexRow}>
                            <View style={[CommonStyles.itemIcon, { backgroundColor: '#FF9900', marginRight: 10 }]}>
                                {/* <RestaurantIcon /> */}
                            </View>
                            <Text style={styles.modalText}>{'selectedData?.name'}</Text>
                        </View>
                        <Text style={[styles.modalText, { marginTop: 10, marginBottom: 20 }]}>{t('areyousureyouwanttodeletethisaccount')}</Text>
                        <View style={styles.modalButton}>
                            <CustomButton
                                onPress={() => { setIsVisible(false) }}
                                colors={[Colors.RED, Colors.RED]}
                                style={styles.modalButtonSize}>
                                <Text style={styles.modalButtonText}>{t('delete')}</Text>
                            </CustomButton>
                            <View style={{ width: 10 }} />
                            <CustomButton
                                onPress={() => setIsVisible(false)}
                                style={styles.modalButtonSize}>
                                <Text style={styles.modalButtonText}>{t('cancel')}</Text>
                            </CustomButton>
                        </View>
                    </View>
                </View>
            </Modal>

            <LinearGradient
                colors={[Colors.BLUE, Colors.LIGHT_BLUE]}
                start={{ x: 0, y: 1 }} end={{ x: 0, y: 0 }}
                style={[styles.floating, { bottom: 20 + insets.bottom, right: 20 + insets.right }]}>
                <TouchableOpacity
                    onPress={() => navigation.navigate('AddNewAccountScreen' as never)}
                    style={styles.floatingButton}>
                    <PlusIcon height={20} width={20} />
                </TouchableOpacity>
            </LinearGradient>
        </View>
    )
}

export default AccountsScreen;

const styles = StyleSheet.create({
    header: {
        flex: 1,
        alignItems: 'center'
    },
    headerTitle: {
        color: Colors.WHITE,
        paddingHorizontal: 8,
        ...Fonts.semiBold22
    },
    accountView: {
        marginHorizontal: 10,
        borderRadius: 20,
        backgroundColor: Colors.WHITE,
        shadowColor: "#000",
        shadowOffset: {
            width: 0,
            height: 1,
        },
        shadowOpacity: 0.20,
        shadowRadius: 1.41,
        elevation: 2,
        marginBottom: 20
    },
    accountName: {
        flex: 1,
        paddingLeft: 10,
        color: Colors.BLACK,
        ...Fonts.semiBold18
    },
    accountViewSpace: {
        paddingHorizontal: 12,
        paddingVertical: 10
    },
    line: {
        marginHorizontal: 16,
        borderBottomWidth: 0.5,
        borderColor: Colors.LIGHT_GREY
    },
    floating: {
        width: 60,
        height: 60,
        borderRadius: 30,
        position: 'absolute',
        alignItems: 'center',
        justifyContent: 'center'
    },
    floatingButton: {
        width: 60,
        height: 60,
        borderRadius: 30,
        alignItems: 'center',
        justifyContent: 'center'
    },
    modalButton: {
        flexDirection: 'row',
        justifyContent: 'center'
    },
    modalButtonSize: {
        height: 30, width: 90
    },
    modalText: {
        color: Colors.BLACK,
        ...Fonts.semiBold16
    },
    modalButtonText: {
        color: Colors.WHITE,
        ...Fonts.medium14
    },
})