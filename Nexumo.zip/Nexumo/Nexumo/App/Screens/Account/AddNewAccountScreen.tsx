import React, { useState } from "react";
import { FlatList, SafeAreaView, StyleSheet, Text, TouchableOpacity, View } from "react-native";
import CommonStyles from "../styles/CommonStyles";
import { useNavigation } from "@react-navigation/native";
import CustomAppBar from "../../Components/CustomAppBar";
import IconButton from "../../Components/IconButton";
import BackIcon from "../../Assets/svg/back-arrow-white.svg";
import CustomTextInput from "../../Components/CustomTextInput";
import HomeIcon from "../../Assets/svg/home-white.svg"
import CardIcon from "../../Assets/svg/card.svg"
import CashIcon from "../../Assets/svg/cash.svg"
import WalletIcon from "../../Assets/svg/wallet-white.svg"
import PhoneDollarIcon from "../../Assets/svg/phone-dollar.svg"
import NetworkCardIcon from "../../Assets/svg/network-card.svg"
import PoketDollarIcon from "../../Assets/svg/poket-dollar.svg"
import CustomButton from "../../Components/CustomButton";
import { useTranslation } from "react-i18next";
import Loader from "../../Constants/loader";
import { BaseStyle, Colors, Fonts } from "../../Constants";

const HEIGHT = (BaseStyle.DEVICE_HEIGHT / 100)
const WIDTH = (BaseStyle.DEVICE_WIDTH / 100)

const AddNewAccountScreen = (props: any) => {
    const { params } = props.route;
    const { t } = useTranslation();
    const navigation = useNavigation();
    const [selectedIndex, setSelectedIndex] = useState(0)
    const [loading, setLoading] = useState(false)
    const [amount, setAmount] = useState('')
    const [accountName, setAccountName] = useState('')
    const [iconData, setIconData] = useState()
    const [selectedIcon, setSelectedIcon] = useState()

    const iconList = [
        <HomeIcon height={25} width={25} />,
        <CardIcon height={25} width={25} />,
        <CashIcon height={25} width={25} />,
        <WalletIcon height={25} width={25} />,
        <PhoneDollarIcon height={25} width={25} />,
        <NetworkCardIcon height={25} width={25} />,
        <PoketDollarIcon height={25} width={25} />,
        <HomeIcon height={25} width={25} />,
        <CardIcon height={25} width={25} />,
        <CashIcon height={25} width={25} />,
        <WalletIcon height={25} width={25} />,
        <PhoneDollarIcon height={25} width={25} />,
        <NetworkCardIcon height={25} width={25} />,
        <PoketDollarIcon height={25} width={25} />,
        <HomeIcon height={25} width={25} />,
        <CardIcon height={25} width={25} />,
        <CashIcon height={25} width={25} />,
        <WalletIcon height={25} width={25} />,
        <PhoneDollarIcon height={25} width={25} />,
        <NetworkCardIcon height={25} width={25} />,
        <PoketDollarIcon height={25} width={25} />,
    ];

    const AppBar = () => {
        return (
            <CustomAppBar>
                <IconButton onPress={() => navigation.goBack()}>
                    <BackIcon />
                </IconButton>
                <View style={styles.header}>
                    <Text style={styles.headerTitle}>{t('addnewaccount')}</Text>
                </View>
                <View style={{ width: 50 }} />
            </CustomAppBar>
        )
    }

    return (
        <View style={CommonStyles.mainContainer}>
            <Loader loading={loading} />
            <SafeAreaView style={{ backgroundColor: Colors.LIGHT_BLUE }} />
            <AppBar />

            <View style={{ paddingHorizontal: 16, paddingVertical: 10 }}>
                <CustomTextInput
                    value={amount}
                    onChangeText={(t: string) => setAmount(t)}
                    label={t('amount')}
                    placeholder={t('enteramount')}
                    keyboardType={'numeric'}
                    style={{ marginTop: 20 }}
                />
                <CustomTextInput
                    value={accountName}
                    onChangeText={(t: string) => setAccountName(t)}
                    label={t('accountname')}
                    placeholder={t('enteraccountname')}
                    style={{ marginTop: 20 }}
                />

                <Text style={{ marginTop: 16, marginVertical: 8, color: Colors.BLACK, ...Fonts.semiBold18 }}>{t('icons')}</Text>
                <FlatList
                    data={iconList}
                    numColumns={7}
                    columnWrapperStyle={{ paddingVertical: 4, justifyContent: 'space-evenly' }}
                    renderItem={({ item, index }) => {
                        return (
                            <TouchableOpacity
                                onPress={() => setSelectedIndex(index)}
                                style={index == selectedIndex ? styles.selectedIcon : styles.unselectedIcon}>
                                <View style={styles.icon}>
                                    {item}
                                </View>
                            </TouchableOpacity>
                        )
                    }}
                />

                <View style={styles.bottomButton}>
                    <CustomButton onPress={() => {}} style={styles.bottomButtonSize}>
                        <Text style={styles.bottomButtonText}>{t('save')}</Text>
                    </CustomButton>
                    <View style={{ width: 20 }} />
                    <CustomButton onPress={() => navigation.goBack()} style={styles.bottomButtonSize}>
                        <Text style={styles.bottomButtonText}>{t('cancel')}</Text>
                    </CustomButton>
                </View>
            </View>
        </View>
    )
}

export default AddNewAccountScreen;

const styles = StyleSheet.create({
    header: {
        flex: 1,
        alignItems: 'center'
    },
    headerTitle: {
        color: Colors.WHITE,
        paddingHorizontal: 8,
        ...Fonts.semiBold22
    },
    unselectedIcon: {
        marginRight: WIDTH * 1.8, 
        borderWidth: 1, 
        borderColor: 'transparent', 
        padding: 4, 
        borderRadius: 5, 
        alignSelf: 'flex-start'
    },
    selectedIcon: {
        marginRight: WIDTH * 1.8, 
        borderWidth: 1, 
        borderColor: Colors.BLACK, 
        padding: 4, 
        borderRadius: 5, 
        alignSelf: 'flex-start'
    },
    icon: {
        height: 35, 
        width: 35, 
        backgroundColor: Colors.LIGHT_GREY, 
        borderRadius: 5, 
        alignItems: 'center', 
        justifyContent: 'center'
    },
    bottomButton: {
        flexDirection: 'row', 
        padding: 20, 
        justifyContent: 'center'
    },
    bottomButtonSize: {
        height: 35, 
        width: 90
    },
    bottomButtonText: {
        color: Colors.WHITE, 
        ...Fonts.medium16
    }
})