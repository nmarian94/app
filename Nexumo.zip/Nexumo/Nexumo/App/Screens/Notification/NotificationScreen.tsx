import React from "react";
import { Platform, SafeAreaView, ScrollView, StyleSheet, Text, View } from "react-native";
import BackIcon from "../../Assets/svg/back-arrow-white.svg";
import IconButton from "../../Components/IconButton";
import CustomAppBar from "../../Components/CustomAppBar";
import { useNavigation } from "@react-navigation/native";
import CommonStyles from "../styles/CommonStyles";
import IncomeIcon from "../../Assets/svg/income.svg";
import ExpenseIcon from "../../Assets/svg/expense.svg";
import OverallIcon from "../../Assets/svg/overall.svg";
import RestaurantIcon from "../../Assets/svg/restaurant.svg";
import DollarIcon from "../../Assets/svg/dollar.svg";
import ReminderIcon from "../../Assets/svg/reminder.svg";
import { useTranslation } from "react-i18next";
import { Colors, Fonts } from "../../Constants";

const isIos = Platform.OS === "ios"

export default function NotificationScreen() {
    const { t } = useTranslation();
    const navigation = useNavigation();

    const AppBar = () => {
        return (
            <CustomAppBar>
                <IconButton onPress={() => navigation.goBack()}>
                    <BackIcon />
                </IconButton>
                <View style={styles.header}>
                    <Text style={styles.headerTitle}>{t('notification')}</Text>
                </View>
                <View style={{ width: 50 }} />
            </CustomAppBar>
        )
    }

    return (
        <View style={CommonStyles.mainContainer}>
            <SafeAreaView style={{ backgroundColor: Colors.LIGHT_BLUE }} />
            <AppBar />

            <ScrollView>
                <View style={{ padding: 16 }}>
                    <Text style={{ color: Colors.BLACK, ...Fonts.semiBold18 }}>{t('today')}</Text>

                    <View style={styles.notificationItem}>
                        <View style={[CommonStyles.itemIcon, { backgroundColor: '#D43957' }]}>
                            <ExpenseIcon height={30} width={30} />
                        </View>
                        <View style={{ flex: 1, justifyContent: 'center', marginHorizontal: 10 }}>
                            <Text style={styles.title}>Today’s Expense</Text>
                            <Text style={styles.subTitle}>Today’s total expense $30</Text>
                        </View>
                        <Text style={{ color: Colors.GREY, ...Fonts.regular12 }}>1 Min ago</Text>
                    </View>
                    <View style={styles.notificationItem}>
                        <View style={[CommonStyles.itemIcon, { backgroundColor: '#754645' }]}>
                            <IncomeIcon height={30} width={30} />
                        </View>
                        <View style={{ flex: 1, justifyContent: 'center', marginHorizontal: 10 }}>
                            <Text style={styles.title}>Today’s Income</Text>
                            <Text style={styles.subTitle}>Today’s total income $950</Text>
                        </View>
                        <Text style={{ color: Colors.GREY, ...Fonts.regular12 }}>5 min ago</Text>
                    </View>
                </View>

                <View style={{ padding: 16, paddingTop: 0 }}>
                    <Text style={{ color: Colors.BLACK, ...Fonts.semiBold18 }}>{t('thisweek')}</Text>

                    <View style={styles.notificationItem}>
                        <View style={[CommonStyles.itemIcon, { backgroundColor: '#769854' }]}>
                            <RestaurantIcon height={30} width={30} />
                        </View>
                        <View style={{ flex: 1, justifyContent: 'center', marginHorizontal: 10 }}>
                            <Text style={styles.title}>Food budget</Text>
                            <Text style={styles.subTitle}>Almost reach to limit, its 80%</Text>
                        </View>
                        <Text style={{ color: Colors.GREY, ...Fonts.regular12 }}>1 day ago</Text>
                    </View>
                    <View style={styles.notificationItem}>
                        <View style={[CommonStyles.itemIcon, { backgroundColor: '#B16668' }]}>
                            <DollarIcon height={30} width={30} />
                        </View>
                        <View style={{ flex: 1, justifyContent: 'center', marginHorizontal: 10 }}>
                            <Text style={styles.title}>Money Transfer</Text>
                            <Text style={styles.subTitle} numberOfLines={1}>You have successfully sent money to mahi...</Text>
                        </View>
                        <Text style={{ color: Colors.GREY, ...Fonts.regular12 }}>5 min ago</Text>
                    </View>
                    <View style={styles.notificationItem}>
                        <View style={[CommonStyles.itemIcon, { backgroundColor: '#6CA12B' }]}>
                            <ReminderIcon height={30} width={30} />
                        </View>
                        <View style={{ flex: 1, justifyContent: 'center', marginHorizontal: 10 }}>
                            <Text style={styles.title}>Reminder</Text>
                            <Text style={styles.subTitle} numberOfLines={1}>I have to sent money to James</Text>
                        </View>
                        <Text style={{ color: Colors.GREY, ...Fonts.regular12 }}>Jun 18</Text>
                    </View>
                    <View style={styles.notificationItem}>
                        <View style={[CommonStyles.itemIcon, { backgroundColor: '#7E1181' }]}>
                            <ExpenseIcon height={30} width={30} />
                        </View>
                        <View style={{ flex: 1, justifyContent: 'center', marginHorizontal: 10 }}>
                            <Text style={styles.title}>Weekly Expense</Text>
                            <Text style={styles.subTitle} numberOfLines={1}>This week total expense $350</Text>
                        </View>
                        <Text style={{ color: Colors.GREY, ...Fonts.regular12 }}>5 min ago</Text>
                    </View>
                    <View style={styles.notificationItem}>
                        <View style={[CommonStyles.itemIcon, { backgroundColor: '#646262' }]}>
                            <IncomeIcon height={30} width={30} />
                        </View>
                        <View style={{ flex: 1, justifyContent: 'center', marginHorizontal: 10 }}>
                            <Text style={styles.title}>Weekly Income</Text>
                            <Text style={styles.subTitle} numberOfLines={1}>This week total income $950</Text>
                        </View>
                        <Text style={{ color: Colors.GREY, ...Fonts.regular12 }}>Jun 18</Text>
                    </View>
                </View>
            </ScrollView>
        </View>
    )
}

const styles = StyleSheet.create({
    mainContainer: {
        flex: 1
    },
    header: {
        flex: 1,
        alignItems: 'center'
    },
    headerTitle: {
        color: Colors.WHITE,
        paddingHorizontal: 8,
        ...Fonts.semiBold22
    },
    notificationItem: {
        marginVertical: 8,
        padding: 8,
        backgroundColor: Colors.WHITE,
        borderRadius: 20,
        flexDirection: 'row',
        shadowColor: "#000",
        shadowOffset: {
            width: 0,
            height: 1,
        },
        shadowOpacity: 0.20,
        shadowRadius: 1.41,
        elevation: 2,
    },
    title: {
        lineHeight: isIos ? 0 : 22,
        color: Colors.BLACK, ...Fonts.semiBold16
    },
    subTitle: {
        color: Colors.GREY, ...Fonts.regular13
    }
})