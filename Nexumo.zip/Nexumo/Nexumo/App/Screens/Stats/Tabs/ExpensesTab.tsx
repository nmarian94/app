import React from "react";
import { StyleSheet, Text, View } from "react-native";
import HospitalIcon from "../../../Assets/svg/hospital.svg";
import GroceriesIcon from "../../../Assets/svg/groceries.svg";
import GiftIcon from "../../../Assets/svg/gift.svg";
import ShoppingIcon from "../../../Assets/svg/shopping.svg";
import { useTranslation } from "react-i18next";
import CommonStyles from "../../styles/CommonStyles";
import { Colors, Fonts } from "../../../Constants";

const ExpensesTab = () => {
    const { t } = useTranslation();

    return (
        <View style={{ paddingHorizontal: 16 }}>
            <View style={styles.transactionItem}>
                <View style={styles.budgetDataStyle}>
                    <View style={[CommonStyles.itemIcon, { backgroundColor: '#E8504D' }]}>
                        <GroceriesIcon />
                    </View>
                    <View style={{ flex: 1 }}>
                        <Text style={styles.dataLabel}>Groceries</Text>
                        <Text style={styles.dataSubLabel}>
                            <Text style={{ color: Colors.BLACK }}>0 </Text>
                            0 {t('transaction')}
                        </Text>
                    </View>
                    <View style={styles.percentage}>
                        <Text style={{ color: Colors.BLACK, ...Fonts.medium12 }}>0 %</Text>
                    </View>
                </View>
            </View>
            <View style={styles.transactionItem}>
                <View style={styles.budgetDataStyle}>
                    <View style={[CommonStyles.itemIcon, { backgroundColor: '#293377' }]}>
                        <GiftIcon />
                    </View>
                    <View style={{ flex: 1 }}>
                        <Text style={styles.dataLabel}>Gifts</Text>
                        <Text style={styles.dataSubLabel}>
                            <Text style={{ color: Colors.BLACK }}>0 </Text>
                            0 {t('transaction')}
                        </Text>
                    </View>
                    <View style={styles.percentage}>
                        <Text style={{ color: Colors.BLACK, ...Fonts.medium12 }}>0 %</Text>
                    </View>
                </View>
            </View>
            <View style={styles.transactionItem}>
                <View style={styles.budgetDataStyle}>
                    <View style={[CommonStyles.itemIcon, { backgroundColor: '#B16668' }]}>
                        <ShoppingIcon />
                    </View>
                    <View style={{ flex: 1 }}>
                        <Text style={styles.dataLabel}>Shopping</Text>
                        <Text style={styles.dataSubLabel}>
                            <Text style={{ color: Colors.BLACK }}>0 </Text>
                            0 {t('transaction')}
                        </Text>
                    </View>
                    <View style={styles.percentage}>
                        <Text style={{ color: Colors.BLACK, ...Fonts.medium12 }}>0 %</Text>
                    </View>
                </View>
            </View>
            <View style={styles.transactionItem}>
                <View style={styles.budgetDataStyle}>
                    <View style={[CommonStyles.itemIcon, { backgroundColor: '#6CA12B' }]}>
                        <HospitalIcon />
                    </View>
                    <View style={{ flex: 1 }}>
                        <Text style={styles.dataLabel}>Hospital</Text>
                        <Text style={styles.dataSubLabel}>
                            <Text style={{ color: Colors.BLACK }}>0 </Text>
                            0 {t('transaction')}
                        </Text>
                    </View>
                    <View style={styles.percentage}>
                        <Text style={{ color: Colors.BLACK, ...Fonts.medium12 }}>0 %</Text>
                    </View>
                </View>
            </View>
        </View>
    )
}

export default ExpensesTab;

const styles = StyleSheet.create({
    transactionItem: {
        borderBottomWidth: 1, paddingBottom: 10, borderColor: Colors.LIGHT_GREY
    },
    budgetDataStyle: {
        flexDirection: 'row',
        alignItems: 'center',
        paddingTop: 10,
    },
    dataLabel: {
        paddingHorizontal: 10,
        color: Colors.BLACK,
        ...Fonts.semiBold16
    },
    dataSubLabel: {
        color: Colors.GREY, paddingLeft: 10, ...Fonts.regular14
    },
    percentage: {
        height: 35, width: 35, borderWidth: 2, borderRadius: 20, borderColor: Colors.GREY100, alignItems: 'center', justifyContent: 'center'
    }
})