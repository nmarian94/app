import React from "react";
import { StyleSheet, Text, View } from "react-native";
import SalaryIcon from "../../../Assets/svg/salary.svg";
import InterestIcon from "../../../Assets/svg/interest.svg";
import SalesIcon from "../../../Assets/svg/sales.svg";
import CashbackIcon from "../../../Assets/svg/cashback.svg";
import { useTranslation } from "react-i18next";
import CommonStyles from "../../styles/CommonStyles";
import { Colors, Fonts } from "../../../Constants";

const IncomeTab = () => {
    const { t } = useTranslation();

    return (
        <View style={{ paddingHorizontal: 16 }}>
            <View style={styles.transactionItem}>
                <View style={styles.budgetDataStyle}>
                    <View style={[CommonStyles.itemIcon, { backgroundColor: '#B64DE8' }]}>
                        <SalaryIcon />
                    </View>
                    <View style={{ flex: 1 }}>
                        <Text style={styles.dataLabel}>Salary</Text>
                        <Text style={styles.dataSubLabel}>
                            <Text style={{ color: Colors.BLACK }}>$15 </Text>
                            3 {t('transaction')}
                        </Text>
                    </View>
                    <View style={styles.percentage}>
                        <Text style={{ color: Colors.BLACK, ...Fonts.medium12 }}>100%</Text>
                    </View>
                </View>
            </View>
            <View style={styles.transactionItem}>
                <View style={styles.budgetDataStyle}>
                    <View style={[CommonStyles.itemIcon, { backgroundColor: '#45C9C1' }]}>
                        <InterestIcon />
                    </View>
                    <View style={{ flex: 1 }}>
                        <Text style={styles.dataLabel}>Interest</Text>
                        <Text style={styles.dataSubLabel}>
                            <Text style={{ color: Colors.BLACK }}>0 </Text>
                            0 {t('transaction')}
                        </Text>
                    </View>
                    <View style={styles.percentage}>
                        <Text style={{ color: Colors.BLACK, ...Fonts.medium12 }}>0 %</Text>
                    </View>
                </View>
            </View>
            <View style={styles.transactionItem}>
                <View style={styles.budgetDataStyle}>
                    <View style={[CommonStyles.itemIcon, { backgroundColor: '#1757FB' }]}>
                        <SalesIcon />
                    </View>
                    <View style={{ flex: 1 }}>
                        <Text style={styles.dataLabel}>Sales</Text>
                        <Text style={styles.dataSubLabel}>
                            <Text style={{ color: Colors.BLACK }}>0 </Text>
                            0 {t('transaction')}
                        </Text>
                    </View>
                    <View style={styles.percentage}>
                        <Text style={{ color: Colors.BLACK, ...Fonts.medium12 }}>0 %</Text>
                    </View>
                </View>
            </View>
            <View style={styles.transactionItem}>
                <View style={styles.budgetDataStyle}>
                    <View style={[CommonStyles.itemIcon, { backgroundColor: '#FF0000' }]}>
                        <CashbackIcon />
                    </View>
                    <View style={{ flex: 1 }}>
                        <Text style={styles.dataLabel}>Cashback</Text>
                        <Text style={styles.dataSubLabel}>
                            <Text style={{ color: Colors.BLACK }}>0 </Text>
                            0 {t('transaction')}
                        </Text>
                    </View>
                    <View style={styles.percentage}>
                        <Text style={{ color: Colors.BLACK, ...Fonts.medium12 }}>0 %</Text>
                    </View>
                </View>
            </View>
        </View>
    )
}

export default IncomeTab;

const styles = StyleSheet.create({
    transactionItem: {
        borderBottomWidth: 1, paddingBottom: 10, borderColor: Colors.LIGHT_GREY
    },
    budgetDataStyle: {
        flexDirection: 'row',
        alignItems: 'center',
        paddingTop: 10,
    },
    dataLabel: {
        paddingHorizontal: 10,
        color: Colors.BLACK,
        ...Fonts.semiBold16
    },
    dataSubLabel: {
        color: Colors.GREY, paddingLeft: 10, ...Fonts.regular14
    },
    percentage: {
        height: 35, width: 35, borderWidth: 2, borderRadius: 20, borderColor: Colors.GREY100, alignItems: 'center', justifyContent: 'center'
    }
})