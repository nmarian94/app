import React, { useState } from "react";
import { Image, SafeAreaView, ScrollView, StyleSheet, Text, TouchableOpacity, View } from "react-native";
import DrawerIcon from "../../Assets/svg/drawer.svg";
import CalendarIcon from "../../Assets/svg/calendar.svg";
import DownArrowIcon from "../../Assets/svg/down-arrow.svg";
import DollarIcon from "../../Assets/svg/dollar.svg";
import IncomeIcon from "../../Assets/svg/income.svg";
import ExpenseIcon from "../../Assets/svg/expense.svg";
import OverallIcon from "../../Assets/svg/overall.svg";
import IconButton from "../../Components/IconButton";
import CustomAppBar from "../../Components/CustomAppBar";
import { LineChart } from "react-native-gifted-charts";
import CommonStyles from "../styles/CommonStyles";
import SpaceStyles from "../styles/SpaceStyles";
import { useTranslation } from "react-i18next";
import CustomButton from "../../Components/CustomButton";
import ExpensesTab from "./Tabs/ExpensesTab";
import IncomeTab from "./Tabs/IncomeTab";
import { useNavigation } from "@react-navigation/native";
import { useDrawerStatus } from "@react-navigation/drawer";
import SelectAccountModal from "../../Components/SelectAccountModal";
import CalendarModal from "../../Components/CalendarModal";
import Loader from "../../Constants/loader";
import { BaseStyle, Colors, Fonts } from "../../Constants";

const HEIGHT = (BaseStyle.DEVICE_HEIGHT / 100)
const WIDTH = (BaseStyle.DEVICE_WIDTH / 100)

export default function StatsScreen() {
    const { t } = useTranslation();
    const navigation = useNavigation();
    const isDrawerOpen = useDrawerStatus() === 'open';
    const [tab, setTab] = useState('expenses');
    const [isVisible, setIsVisible] = useState(false)
    const [showCalendars, setShowCalendars] = useState(false);
    const [loading, setLoading] = useState(false);
    const [selectedDate, setSelectedDate] = useState({});
    const data = [
        { value: 30, labelComponent: () => year('1988'), },
        { value: 50, labelComponent: () => year('1989'), },
        { value: 65, labelComponent: () => year('1990'), },
        { value: 58, labelComponent: () => year('1991'), },
        { value: 75, labelComponent: () => year('1992'), },
        { value: 58, labelComponent: () => year('1993'), }
    ]
    const data2 = [{ value: 20 }, { value: 40 }, { value: 50 }, { value: 50 }, { value: 65 }, { value: 50 }]

    const year = (data: any) => {
        return <Text style={{ color: Colors.BLACK, alignSelf: 'center' }}>{data}</Text>
    }

    const AppBar = () => {
        return (
            <CustomAppBar>
                <IconButton onPress={() => isDrawerOpen ? navigation.closeDrawer() : navigation.openDrawer()}>
                    <DrawerIcon height={26} width={26} />
                </IconButton>
                <View style={CommonStyles.header}>
                    <TouchableOpacity
                        onPress={() => setIsVisible(true)}
                        style={CommonStyles.headerTitleWrapper}>
                        <DollarIcon height={16} width={16} />
                        <Text style={CommonStyles.headerTitle}>{t('total')}</Text>
                        <DownArrowIcon height={12} width={12} />
                    </TouchableOpacity>
                    <Text style={CommonStyles.headerSubTitle}>{'\$1200'}</Text>
                </View>
                <IconButton onPress={() => setShowCalendars(true)}>
                    <CalendarIcon height={26} width={26} />
                </IconButton>
            </CustomAppBar>
        )
    }

    return (
        <View style={CommonStyles.mainContainer}>
            <Loader loading={loading} />
            <SafeAreaView style={{ backgroundColor: Colors.LIGHT_BLUE }} />
            <AppBar />

            <ScrollView>
                <View style={styles.graph}>
                    <LineChart
                        data={data}
                        data2={data2}
                        color1={Colors.BLUE}
                        color2={Colors.RED}
                        dataPointsColor1={Colors.BLUE}
                        dataPointsColor2={Colors.RED}
                        height={180}
                        width={WIDTH * 70}
                    />
                </View>

                <View style={[SpaceStyles.flexRow, { justifyContent: 'space-evenly' }]}>
                    <View style={[SpaceStyles.alignSpaceCenter, CommonStyles.roundedBox]}>
                        <View style={CommonStyles.budgetTopRound}>
                            <IncomeIcon height={32} width={32} />
                        </View>
                        <Text style={{ color: Colors.BLACK, ...Fonts.semiBold16 }}>{t('income')}</Text>
                        <Text style={{ color: Colors.GREY, ...Fonts.regular15 }}>$150</Text>
                    </View>
                    <View style={[SpaceStyles.alignSpaceCenter, CommonStyles.roundedBox]}>
                        <View style={CommonStyles.budgetTopRound}>
                            <ExpenseIcon height={32} width={32} />
                        </View>
                        <Text style={{ color: Colors.BLACK, ...Fonts.semiBold16 }}>{t('expense')}</Text>
                        <Text style={{ color: Colors.GREY, ...Fonts.regular15 }}>$150</Text>
                    </View>
                    <View style={[SpaceStyles.alignSpaceCenter, CommonStyles.roundedBox]}>
                        <View style={CommonStyles.budgetTopRound}>
                            <OverallIcon height={38} width={38} />
                        </View>
                        <Text style={{ color: Colors.BLACK, ...Fonts.semiBold16 }}>{t('overall')}</Text>
                        <Text style={{ color: Colors.GREY, ...Fonts.regular15 }}>$150</Text>
                    </View>
                </View>

                <View style={styles.tabs}>
                    <CustomButton
                        onPress={() => setTab('expenses')}
                        style={[styles.buttonStyle, tab !== 'expenses' && { borderWidth: 1, borderColor: Colors.BLUE }]}
                        colors={tab == 'expenses' ? [Colors.BLUE, Colors.LIGHT_BLUE] : [Colors.WHITE, Colors.WHITE]}>
                        <Text style={[styles.buttonText, { color: tab == 'expenses' ? Colors.WHITE : Colors.BLUE }]}>{t('expenses')}</Text>
                    </CustomButton>
                    <CustomButton
                        onPress={() => setTab('income')}
                        style={[styles.buttonStyle, tab !== 'income' && { borderWidth: 1, borderColor: Colors.BLUE }]}
                        colors={tab == 'income' ? [Colors.BLUE, Colors.LIGHT_BLUE] : [Colors.WHITE, Colors.WHITE]}>
                        <Text style={[styles.buttonText, { color: tab == 'income' ? Colors.WHITE : Colors.BLUE }]}>{t('income')}</Text>
                    </CustomButton>
                </View>

                <View style={{ paddingVertical: 12, width: '75%', alignSelf: 'center' }}>
                    {tab === 'expenses'
                        ? <Text style={{ color: Colors.BLACK, ...Fonts.semiBold14 }}>{t('expensecategoriesbreakdown')}</Text>
                        : <Text style={{ color: Colors.BLACK, ...Fonts.semiBold14, alignSelf: 'flex-end' }}>{t('incomecategoriesbreakdown')}</Text>}
                    <View style={[styles.progress, { width: '100%' }]} />
                </View>

                <View style={{ paddingHorizontal: 16, flexDirection: 'row', justifyContent: 'space-between' }}>
                    <Text style={{ color: Colors.BLACK, ...Fonts.medium16 }}>{t('categories')}</Text>
                    <Text style={{ color: Colors.BLACK, ...Fonts.medium16 }}>{t('percentage')}</Text>
                </View>

                {/* <View style={{ paddingHorizontal: 16 }}>
                    {statsData?.data?.map((item) => {
                        return (
                            <View style={styles.transactionItem}>
                                <View style={styles.budgetDataStyle}>
                                    <View style={[CommonStyles.itemIcon, { backgroundColor: item?.category_data?.color }]}>
                                        <Image source={{ uri: item?.category_data?.icon }} style={{ height: 24, width: 24 }} />
                                    </View>
                                    <View style={{ flex: 1 }}>
                                        <Text style={styles.dataLabel}>{item?.category_data?.name}</Text>
                                        <Text style={styles.dataSubLabel}>
                                            {item?.category_data?.transaction} {t('transaction')}
                                        </Text>
                                    </View>
                                    <View style={styles.percentage}>
                                        <Text style={{ color: Colors.BLACK, ...Fonts.medium12 }}>{item?.category_data?.percentage} %</Text>
                                    </View>
                                </View>
                            </View>
                        )
                    })}
                </View> */}
                {tab === 'expenses' ? <ExpensesTab /> : <IncomeTab />}
            </ScrollView>
            <SelectAccountModal isVisible={isVisible} setIsVisible={setIsVisible} />

            <CalendarModal showCalendars={showCalendars} setShowCalendars={setShowCalendars} setSelectedDate={setSelectedDate} />
        </View>
    )
}

const styles = StyleSheet.create({
    mainContainer: {
        flex: 1
    },
    graph: {
        margin: 16, marginBottom: 0, padding: 10, borderWidth: 1, borderColor: Colors.BLUE, borderRadius: 20
    },
    tabs: {
        flexDirection: 'row', alignItems: 'center', justifyContent: 'space-evenly', marginVertical: 4
    },
    buttonStyle: {
        height: 40, width: 130
    },
    buttonText: {
        ...Fonts.semiBold16
    },
    progress: {
        height: 15, marginTop: 10, marginBottom: 5, borderRadius: 30, backgroundColor: Colors.LIGHT_BLUE
    },
    transactionItem: {
        borderBottomWidth: 1, paddingBottom: 10, borderColor: Colors.LIGHT_GREY
    },
    budgetDataStyle: {
        flexDirection: 'row',
        alignItems: 'center',
        paddingTop: 10,
    },
    dataLabel: {
        paddingHorizontal: 10,
        color: Colors.BLACK,
        ...Fonts.semiBold16
    },
    dataSubLabel: {
        color: Colors.GREY, paddingLeft: 10, ...Fonts.regular14
    },
    percentage: {
        height: 40, width: 40, borderWidth: 2, borderRadius: 20, borderColor: Colors.GREY100, alignItems: 'center', justifyContent: 'center'
    },
})