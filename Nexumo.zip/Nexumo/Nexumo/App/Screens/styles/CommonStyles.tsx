import { StyleSheet, Platform } from 'react-native'
import { BaseStyle, Colors, Fonts } from '../../Constants'

const isIos = Platform.OS === "ios"
const HEIGHT = (BaseStyle.DEVICE_HEIGHT / 100)
const WIDTH = (BaseStyle.DEVICE_WIDTH / 100)
const PADDING = BaseStyle.PADDING

const CommonStyles = StyleSheet.create({
    mainContainer: {
        flex: 1,
        backgroundColor: Colors.WHITE
    },
    header: {
        flex: 1,
        alignItems: 'center'
    },
    headerTitleWrapper: {
        marginTop: isIos ? 0 : 12,
        flexDirection: 'row',
        alignItems: 'center'
    },
    headerTitle: {
        color: Colors.WHITE,
        paddingHorizontal: 8,
        ...Fonts.semiBold18
    },
    headerSubTitle: {
        marginBottom: isIos ? 0 : 12,
        color: Colors.WHITE,
        lineHeight: isIos ? 0 : 30,
        ...Fonts.semiBold25
    },
    modalMainView: {
        margin: 30, 
        borderRadius: 20, 
        backgroundColor: Colors.WHITE, 
        alignItems: 'center', 
        justifyContent: 'center'
    },
    modalCell: { 
        paddingHorizontal: 20, 
        paddingVertical: 10, 
        flexDirection: 'row', 
        width: '100%', 
        alignItems: 'center', 
        justifyContent: 'space-between' 
    },
    budgetTopRound: {
        height: 50, 
        width: 50, 
        backgroundColor: Colors.BLUE, 
        borderRadius: 30, 
        alignItems: 'center', 
        justifyContent: 'center',
        marginBottom: 4
    },
    itemIcon: {
        height: 40,
        width: 40,
        borderRadius: 30,
        alignItems: 'center',
        justifyContent: 'center'
    },
    shadow: {
        shadowColor: "#000",
        shadowOffset: {
            width: 0,
            height: 1,
        },
        shadowOpacity: 0.20,
        shadowRadius: 1.41,
        elevation: 2,
    },
    roundedBox: {
        backgroundColor: Colors.WHITE, 
        width: '28%', 
        borderRadius: 20, 
        paddingHorizontal: 2,
        paddingVertical: 6, 
        marginVertical: 16,
        shadowColor: "#000",
        shadowOffset: {
            width: 0,
            height: 1,
        },
        shadowOpacity: 0.20,
        shadowRadius: 1.41,
        elevation: 2,
    },
    checkBox: {
        height: 18, 
        width: 18, 
        marginRight: 5, 
        borderWidth: 2, 
        borderColor: Colors.BLUE, 
        borderRadius: 2
    },
    calendarButtonView: {
        marginBottom: 10, 
        flexDirection: 'row', 
        alignItems: 'center', 
        alignSelf: 'flex-end'
    },
    calendarButton: {
        height: 30, 
        width: 70, 
        alignItems: 'center', 
        justifyContent: 'center', 
        borderRadius: 20
    },
    divider: {
        borderWidth: 0.5, 
        borderColor: Colors.LIGHT_GREY, 
        width: '100%'
    },
    calenderContainer: { 
        marginVertical: 20, 
        backgroundColor: Colors.BLUE, 
        borderRadius: 20 
    }
})

export default CommonStyles