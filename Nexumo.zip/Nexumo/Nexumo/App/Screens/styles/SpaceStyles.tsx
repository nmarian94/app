import { StyleSheet, Platform } from 'react-native'
import { BaseStyle } from '../../Constants'

const isIos = Platform.OS === "ios"

const HEIGHT = (BaseStyle.DEVICE_HEIGHT / 100)
const WIDTH = (BaseStyle.DEVICE_WIDTH / 100)

const SpaceStyles = StyleSheet.create({
    alignSpaceBlock: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between'
    },
    alignSpaceCenter: {
        alignItems: 'center',
        justifyContent: 'center'
    },
    flexRow: {
        flexDirection: 'row',
        alignItems: 'center'
    },
    alignSelf: {
        alignSelf: 'center'
    },
    vertical4: {
        marginVertical: HEIGHT * 4
    },
    bottom5: {
        marginBottom: HEIGHT * 5
    },
    vertical5: {
        marginVertical: HEIGHT * 5
    },
    top2: {
        marginTop: HEIGHT * 2
    },
    top8: {
        marginTop: HEIGHT * 8
    },
    top18: {
        marginTop: HEIGHT * 18
    },
    top20: {
        marginTop: HEIGHT * 20
    },
    vertical2: {
        marginVertical: HEIGHT * 2
    },
    vertical1: {
        marginVertical: HEIGHT * 1
    },
    left3: {
        marginLeft: WIDTH * 3
    },
    left6: {
        marginLeft: WIDTH * 6
    },
    right2: {
        marginRight: WIDTH * 2
    },
    right5: {
        marginRight: WIDTH * 5
    },
    bottom12: {
        marginBottom: HEIGHT * 12
    },
    widthText: {
        width: WIDTH * 70,
        textAlign: 'center',
        alignSelf: 'center'
    },
    rowWrap: {
        flexDirection: "row",
        flexWrap: "wrap",
        alignItems: 'center'
    },
    bottom1: {
        marginBottom: HEIGHT * 1
    },
    bottom2: {
        marginBottom: HEIGHT * 2
    },
    height70: {
        height: HEIGHT * 70
    },
    height80: {
        height: HEIGHT * 80
    },
    spaceHorizontal10: {
        paddingHorizontal: WIDTH * 10
    },
    spacingInput: {
        marginTop: 8,
        marginBottom: 22
    },
    width90: {
        width: WIDTH * 90
    },
    width40: {
        width: WIDTH * 42
    },
    top1: {
        marginTop: HEIGHT * 1
    },
    width70: {
        width: WIDTH * 70
    },
    horizontal3: {
        marginHorizontal: WIDTH * 3
    },
    horizontal4: {
        marginHorizontal: WIDTH * 4
    },
    horizontal5: {
        marginHorizontal: WIDTH * 5
    },
    width80: {
        width: WIDTH * 80
    },
    width75: {
        width: WIDTH * 75
    },
    width25: {
        width: WIDTH * 25
    },
    width20: {
        width: WIDTH * 20
    },
    width15: {
        width: WIDTH * 15
    },
    width30: {
        width: WIDTH * 30
    },
    width62: {
        width: WIDTH * 63
    },
    centerProgress: {
        width: WIDTH * 9,
        alignItems: 'center',
        justifyContent: 'center'
    },
    padding2: {
        paddingVertical: HEIGHT * 2
    },
    top05: {
        marginTop: HEIGHT * 0.5
    },
    top5: {
        marginTop: HEIGHT * 5
    },
    left2: {
        marginLeft: WIDTH * 2
    },
    padding5: {
        paddingHorizontal: WIDTH * 5
    },
    width50: {
        width: WIDTH * 50
    },
    width60: {
        width: WIDTH * 60
    },
    settingBlock: {
        paddingVertical: 10,
        paddingHorizontal: WIDTH * 4,
    },
    height8: {
        height: HEIGHT * 7.5,
    }
})

export default SpaceStyles
