import React, { useState } from "react";
import { SafeAreaView, ScrollView, StyleSheet, Text, TouchableOpacity, View } from "react-native";
import DrawerIcon from "../../Assets/svg/drawer.svg";
import CalendarIcon from "../../Assets/svg/calendar.svg";
import DownArrowIcon from "../../Assets/svg/down-arrow.svg";
import DollarIcon from "../../Assets/svg/dollar.svg";
import PlusIcon from "../../Assets/svg/plus.svg";
import IconButton from "../../Components/IconButton";
import CustomAppBar from "../../Components/CustomAppBar";
import CustomButton from "../../Components/CustomButton";
import ExpensesTab from "./Tabs/ExpensesTab";
import IncomeTab from "./Tabs/IncomeTab";
import CommonStyles from "../styles/CommonStyles";
import '../../Assets/i18n/i18n';
import { useTranslation } from "react-i18next";
import { useFocusEffect, useNavigation } from "@react-navigation/native";
import { useDrawerStatus } from '@react-navigation/drawer';
import SelectAccountModal from "../../Components/SelectAccountModal";
import CalendarModal from "../../Components/CalendarModal";
import SpaceStyles from "../styles/SpaceStyles";
import Loader from "../../Constants/loader";
import moment from "moment";
import { Colors, Fonts } from "../../Constants";

export default function HomeScreen() {
    const { t } = useTranslation();
    const navigation = useNavigation();
    const [tab, setTab] = useState('expenses');
    const [isVisible, setIsVisible] = useState(false);
    const [showCalendars, setShowCalendars] = useState(false);
    const [loading, setLoading] = useState(false);
    const isDrawerOpen = useDrawerStatus() === 'open';

    const [dayType, setDayType] = useState('week'); // day, week, month, year, period

    const [date, setDate] = useState(moment());
    const startOfWeek = moment(date).startOf('isoWeek');
    const endOfWeek = moment(date).endOf('isoWeek');
    const [selectedDate, setSelectedDate] = useState({});

    const days = [];
    let day = startOfWeek;

    while (day <= endOfWeek) {
        days.push(day);
        day = moment(day).add(1, 'days');
    }

    const AppBar = () => {
        return (
            <CustomAppBar>
                <IconButton onPress={() => isDrawerOpen ? navigation.closeDrawer() : navigation.openDrawer()}>
                    <DrawerIcon height={26} width={26} />
                </IconButton>
                <View style={CommonStyles.header}>
                    <TouchableOpacity
                        onPress={() => setIsVisible(true)}
                        style={CommonStyles.headerTitleWrapper}>
                        <DollarIcon height={16} width={16} />
                        <Text style={CommonStyles.headerTitle}>{t('total')}</Text>
                        <DownArrowIcon height={12} width={12} />
                    </TouchableOpacity>
                    <Text style={CommonStyles.headerSubTitle}>{'\$1200'}</Text>
                </View>
                <IconButton onPress={() => setShowCalendars(true)}>
                    <CalendarIcon height={26} width={26} />
                </IconButton>
            </CustomAppBar>
        )
    }

    return (
        <View style={CommonStyles.mainContainer}>
            <Loader loading={loading} />
            <SafeAreaView style={{ backgroundColor: Colors.LIGHT_BLUE }} />
            <AppBar />
            <ScrollView>
                <View style={[SpaceStyles.flexRow, SpaceStyles.alignSpaceCenter, { marginVertical: 16 }]}>
                    <CustomButton
                        onPress={() => setTab('expenses')}
                        style={[styles.buttonStyle, tab !== 'expenses' && { borderWidth: 1, borderColor: Colors.BLUE }]}
                        colors={tab == 'expenses' ? [Colors.BLUE, Colors.LIGHT_BLUE] : [Colors.WHITE, Colors.WHITE]}>
                        <Text style={[styles.buttonText, { color: tab == 'expenses' ? Colors.WHITE : Colors.BLUE }]}>{t('expenses')}</Text>
                    </CustomButton>
                    <CustomButton
                        onPress={() => navigation.navigate('AddDataScreen' as never)}
                        style={{ height: 35, width: 35, marginHorizontal: 16 }}>
                        <PlusIcon />
                    </CustomButton>
                    <CustomButton
                        onPress={() => setTab('income')}
                        style={[styles.buttonStyle, tab !== 'income' && { borderWidth: 1, borderColor: Colors.BLUE }]}
                        colors={tab == 'income' ? [Colors.BLUE, Colors.LIGHT_BLUE] : [Colors.WHITE, Colors.WHITE]}>
                        <Text style={[styles.buttonText, { color: tab == 'income' ? Colors.WHITE : Colors.BLUE }]}>{t('income')}</Text>
                    </CustomButton>
                </View>
                {tab === 'expenses'
                    ? <ExpensesTab setShowCalendars={setShowCalendars} date={date} dayType={dayType} setDayType={setDayType} markedDates={selectedDate} />
                    : <IncomeTab setShowCalendars={setShowCalendars} date={date} dayType={dayType} setDayType={setDayType} markedDates={selectedDate} />}
            </ScrollView>
            <SelectAccountModal isVisible={isVisible} setIsVisible={setIsVisible} />

            <CalendarModal showCalendars={showCalendars} setShowCalendars={setShowCalendars} setSelectedDate={setSelectedDate} />
        </View>
    )
}

const styles = StyleSheet.create({
    mainContainer: {
        flex: 1
    },
    buttonStyle: {
        height: 40, width: 130
    },
    buttonText: {
        ...Fonts.semiBold16
    }
})