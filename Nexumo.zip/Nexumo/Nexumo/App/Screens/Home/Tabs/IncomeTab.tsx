import React, { useEffect, useState } from "react";
import { Image, StyleSheet, Text, TouchableOpacity, View } from "react-native";
import SalaryIcon from "../../../Assets/svg/salary.svg";
import InterestIcon from "../../../Assets/svg/interest.svg";
import SalesIcon from "../../../Assets/svg/sales.svg";
import CashbackIcon from "../../../Assets/svg/cashback.svg";
import { PieChart } from "react-native-gifted-charts";
import { useTranslation } from "react-i18next";
import moment from "moment";
import { useNavigation } from "@react-navigation/native";
import { Colors, Fonts } from "../../../Constants";

const IncomeTab = ({ setShowCalendars, date, dayType, setDayType, markedDates }: any) => {
    const { t } = useTranslation();
    const [onlyDate, setOnlyDate] = useState('')
    const [startdate, setStartDate] = useState('')
    const [enddate, setEndDate] = useState('')
    const [month, setMonth] = useState('')
    const [year, setYear] = useState('')

    useEffect(() => {
        if (dayType == 'day') {
            setOnlyDate(moment(date).format('MMM DD'))
        } else if (dayType == 'week') {
            setStartDate(moment(date).startOf('isoWeek').format('MMM DD'))
            setEndDate(moment(date).endOf('isoWeek').format('MMM DD'))
        } else if (dayType == 'month') {
            setMonth(moment(date).endOf('month').format('MMM YYYY'))
        } else if (dayType == 'year') {
            setYear(moment(date).endOf('year').format('YYYY'))
        } else {
            const markedDateKeys = Object.keys(markedDates);
            setStartDate(moment(markedDateKeys.length > 0 ? markedDateKeys[0] : null).format('MMM DD'))
            setEndDate(moment(markedDateKeys.length > 0 ? markedDateKeys[markedDateKeys.length - 1] : null).format('MMM DD'))
        }
    }, [date, dayType, markedDates])

    const data = [
        // { value: 360, color: '#cccccc' },
        { value: 90, color: '#45C9C1' },
        { value: 140, color: '#FF0000' },
        { value: 40, color: '#1757FB' },
        { value: 90, color: '#B64DE8' }
    ]

    const list = [
        {
            icon: <SalaryIcon />,
            backgroundColor: '#B64DE8',
            label: t('salary'),
            percent: '20%',
            price: '\$15'
        },
        {
            icon: <InterestIcon />,
            backgroundColor: '#45C9C1',
            label: t('interest'),
            percent: '10%',
            price: '\$5'
        },
        {
            icon: <SalesIcon />,
            backgroundColor: '#1757FB',
            label: t('sales'),
            percent: '20%',
            price: '\$15'
        },
        {
            icon: <CashbackIcon />,
            backgroundColor: '#FF0000',
            label: t('cashback'),
            percent: '10%',
            price: '\$5'
        },
    ]

    return (
        <View>
            <View style={styles.pieChartWrapper}>
                <View style={styles.pieContainer}>
                    <TouchableOpacity
                        onPress={() => setDayType('day')}
                        style={dayType == 'day' && { borderBottomWidth: 1, borderColor: Colors.BLUE }}>
                        <Text style={[styles.pieButtonText, dayType == 'day' && styles.pieSelectedButtonText]}>{t('day')}</Text>
                    </TouchableOpacity>
                    <TouchableOpacity
                        onPress={() => setDayType('week')}
                        style={dayType == 'week' && { borderBottomWidth: 1, borderColor: Colors.BLUE }}>
                        <Text style={[styles.pieButtonText, dayType == 'week' && styles.pieSelectedButtonText]}>{t('week')}</Text>
                    </TouchableOpacity>
                    <TouchableOpacity
                        onPress={() => setDayType('month')}
                        style={dayType == 'month' && { borderBottomWidth: 1, borderColor: Colors.BLUE }}>
                        <Text style={[styles.pieButtonText, dayType == 'month' && styles.pieSelectedButtonText]}>{t('month')}</Text>
                    </TouchableOpacity>
                    <TouchableOpacity
                        onPress={() => setDayType('year')}
                        style={dayType == 'year' && { borderBottomWidth: 1, borderColor: Colors.BLUE }}>
                        <Text style={[styles.pieButtonText, dayType == 'year' && styles.pieSelectedButtonText]}>{t('year')}</Text>
                    </TouchableOpacity>
                    <TouchableOpacity
                        onPress={() => { setDayType('period'), setShowCalendars(true) }}
                        style={dayType == 'period' && { borderBottomWidth: 1, borderColor: Colors.BLUE }}>
                        <Text style={[styles.pieButtonText, dayType == 'period' && styles.pieSelectedButtonText]}>{t('period')}</Text>
                    </TouchableOpacity>
                </View>
                <Text style={{ color: Colors.BLUE, ...Fonts.semiBold16, marginBottom: 10 }}>{
                    dayType == 'day' ? onlyDate : dayType == 'week' ? `${startdate} - ${enddate}` : dayType == 'month' ? `${month}` : dayType == 'year' ? `${year}` : `${startdate} - ${enddate}`
                }</Text>
                <PieChart
                    data={data}
                    radius={60}
                    donut
                    innerRadius={20}
                    focusOnPress
                    centerLabelComponent={() => <Text style={styles.pieCenterText}>$70</Text>}
                />
            </View>
            {list.map((item) => {
                return (
                    <View style={styles.expensesDataStyle}>
                        <View style={[styles.icon, { backgroundColor: item.backgroundColor }]}>
                            {item.icon}
                        </View>
                        <Text style={styles.dataLabel}>{item.label}</Text>
                        <Text style={styles.dataPersent}>{item.percent}</Text>
                        <Text style={styles.dataPrice}>{item.price}</Text>
                    </View>
                )
            })}
            <View style={{ height: 10 }} />
        </View>
    )
}

export default IncomeTab;

const styles = StyleSheet.create({
    pieContainer: {
        flexDirection: 'row',
        width: '100%',
        paddingVertical: 12,
        justifyContent: 'space-evenly'
    },
    pieButtonText: {
        paddingBottom: 4,
        color: Colors.GREY,
        ...Fonts.medium15
    },
    pieSelectedButtonText: {
        color: Colors.BLUE,
        ...Fonts.semiBold15
    },
    pieChartWrapper: {
        borderWidth: 1,
        borderColor: Colors.BLUE,
        borderRadius: 20,
        marginHorizontal: 16,
        alignItems: 'center',
        paddingBottom: 8,
    },
    pieCenterText: {
        color: Colors.BLUE,
        ...Fonts.semiBold16
    },
    expensesDataStyle: {
        flexDirection: 'row',
        alignItems: 'center',
        marginHorizontal: 16,
        marginTop: 10,
        padding: 10,
        borderRadius: 20,
        backgroundColor: Colors.WHITE,
        shadowColor: "#000",
        shadowOffset: {
            width: 0,
            height: 1,
        },
        shadowOpacity: 0.20,
        shadowRadius: 1.41,
        elevation: 2,
    },
    icon: {
        height: 40,
        width: 40,
        borderRadius: 30,
        alignItems: 'center',
        justifyContent: 'center'
    },
    dataLabel: {
        flex: 1,
        paddingLeft: 10,
        color: Colors.BLACK,
        ...Fonts.semiBold16
    },
    dataPersent: {
        color: Colors.BLACK, 
        paddingHorizontal: 10, 
        ...Fonts.regular16
    },
    dataPrice: {
        color: Colors.BLACK, 
        ...Fonts.semiBold16
    }
})