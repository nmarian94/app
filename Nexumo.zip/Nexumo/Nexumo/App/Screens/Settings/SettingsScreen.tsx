import { useNavigation } from "@react-navigation/native";
import React from "react";
import { SafeAreaView, StyleSheet, Text, TouchableOpacity, View } from "react-native";
import CommonStyles from "../styles/CommonStyles";
import CustomAppBar from "../../Components/CustomAppBar";
import IconButton from "../../Components/IconButton";
import BackIcon from "../../Assets/svg/back-arrow-white.svg";
import LanguageIcon from "../../Assets/svg/language.svg";
import CurrencyIcon from "../../Assets/svg/currency.svg";
import BalanceIcon from "../../Assets/svg/balance.svg";
import LogoutIcon from "../../Assets/svg/logout.svg";
import ArrowRightIcon from "../../Assets/svg/arrow-right-blue.svg";
import { useTranslation } from "react-i18next";
import { Colors, Fonts } from "../../Constants";

const SettingsScreen = () => {
    const { t } = useTranslation();
    const navigation = useNavigation();

    const AppBar = () => {
        return (
            <CustomAppBar>
                <IconButton onPress={() => navigation.goBack()}>
                    <BackIcon />
                </IconButton>
                <View style={styles.header}>
                    <Text style={styles.headerTitle}>{t('settings')}</Text>
                </View>
                <View style={{ width: 50 }} />
            </CustomAppBar>
        )
    }

    const handleLogout = () => { }

    return (
        <View style={CommonStyles.mainContainer}>
            <SafeAreaView style={{ backgroundColor: Colors.LIGHT_BLUE }} />
            <AppBar />

            <TouchableOpacity style={styles.drawerItem}>
                <View style={styles.iconView}>
                    <LanguageIcon />
                </View>
                <View style={styles.drawerTextView}>
                    <Text style={styles.drawerItemText}>{t('language')}</Text>
                </View>
                <ArrowRightIcon />
            </TouchableOpacity>
            <View style={styles.line} />
            <TouchableOpacity style={styles.drawerItem}>
                <View style={styles.iconView}>
                    <CurrencyIcon />
                </View>
                <View style={styles.drawerTextView}>
                    <Text style={styles.drawerItemText}>{t('currency')}</Text>
                </View>
                <ArrowRightIcon />
            </TouchableOpacity>
            <View style={styles.line} />
            <TouchableOpacity style={styles.drawerItem}>
                <View style={styles.iconView}>
                    <BalanceIcon />
                </View>
                <View style={styles.drawerTextView}>
                    <Text style={styles.drawerItemText}>{t('showbalance')}</Text>
                </View>
                <ArrowRightIcon />
            </TouchableOpacity>
            <View style={styles.line} />
            <TouchableOpacity onPress={handleLogout} style={styles.drawerItem}>
                <View style={styles.iconView}>
                    <LogoutIcon />
                </View>
                <View style={styles.drawerTextView}>
                    <Text style={styles.drawerItemText}>{t('logout')}</Text>
                </View>
            </TouchableOpacity>
            <View style={styles.line} />
        </View>
    )
}

export default SettingsScreen;

const styles = StyleSheet.create({
    header: {
        flex: 1,
        alignItems: 'center'
    },
    headerTitle: {
        color: Colors.WHITE,
        paddingHorizontal: 8,
        ...Fonts.semiBold22
    },
    iconView: {
        width: 24, alignItems: 'center'
    },
    drawerItem: {
        margin: 16, flexDirection: 'row', alignItems: 'center'
    },
    drawerTextView: {
        flex: 1, paddingHorizontal: 10
    },
    drawerItemText: {
        color: Colors.BLACK, ...Fonts.nunitoSemiBold18
    },
    line: {
        marginHorizontal: 16, borderBottomWidth: 0.5, borderColor: Colors.LIGHT_GREY
    }
})