import React, { useState } from "react";
import { useNavigation } from "@react-navigation/native";
import { SafeAreaView, ScrollView, StyleSheet, Text, TouchableOpacity, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import CustomAppBar from "../../Components/CustomAppBar";
import IconButton from "../../Components/IconButton";
import BackIcon from "../../Assets/svg/back-arrow-white.svg";
import ShoppingIcon from "../../Assets/svg/shopping.svg";
import CommonStyles from "../styles/CommonStyles";
import CustomTextInput from "../../Components/CustomTextInput";
import CustomButton from "../../Components/CustomButton";
import { useTranslation } from "react-i18next";
import SpaceStyles from "../styles/SpaceStyles";
import Loader from "../../Constants/loader";
import { Colors, Fonts } from "../../Constants";

const AddCategoriesScreen = () => {
    const { t } = useTranslation();
    const insets = useSafeAreaInsets();
    const navigation = useNavigation();
    const [colorCode, setColorCode] = useState()
    const [category, setCategory] = useState('')
    const [parentCategory, setParentCategory] = useState('')
    const [selectedIcon, setSelectedIcon] = useState('')
    const [loading, setLoading] = useState(false)
    const [iconData, setIconData] = useState()
    const [colorData, setColorData] = useState()

    const colorList = [
        '#E8504D', '#2381FD', '#7F7F7F', '#41B5FE', '#FE5A35', '#FFBC00', '#7C54A2', '#A164A9',
        '#004463', '#6CA12B', '#B16668', '#E51C19', '#B6E84D', '#E8AA4D', '#E5E84D', '#4DE8DF',
        '#7E1181', '#453231', '#754645', '#769854', '#85ADC3', '#4DE8C3', '#E84DE2', '#634DE8',
        '#6D0606', '#B13478', '#646262', '#C7C1C1', '#3C7279', '#D43957', '#B64DE8', '#E84D7C',
    ];

    const financeIconList = [
        { id: 1, icon: <ShoppingIcon height={25} width={25} /> },
        { id: 2, icon: <ShoppingIcon height={25} width={25} /> },
        { id: 3, icon: <ShoppingIcon height={25} width={25} /> },
        { id: 4, icon: <ShoppingIcon height={25} width={25} /> },
        { id: 5, icon: <ShoppingIcon height={25} width={25} /> },
        { id: 6, icon: <ShoppingIcon height={25} width={25} /> },
        { id: 7, icon: <ShoppingIcon height={25} width={25} /> },
    ];

    const foodIconList = [
        { id: 8, icon: <ShoppingIcon height={25} width={25} /> },
        { id: 9, icon: <ShoppingIcon height={25} width={25} /> },
        { id: 10, icon: <ShoppingIcon height={25} width={25} /> },
        { id: 11, icon: <ShoppingIcon height={25} width={25} /> },
        { id: 12, icon: <ShoppingIcon height={25} width={25} /> },
        { id: 13, icon: <ShoppingIcon height={25} width={25} /> },
        { id: 14, icon: <ShoppingIcon height={25} width={25} /> },
    ];

    const shoppingIconList = [
        { id: 15, icon: <ShoppingIcon height={25} width={25} /> },
        { id: 16, icon: <ShoppingIcon height={25} width={25} /> },
        { id: 17, icon: <ShoppingIcon height={25} width={25} /> },
        { id: 18, icon: <ShoppingIcon height={25} width={25} /> },
        { id: 19, icon: <ShoppingIcon height={25} width={25} /> },
        { id: 20, icon: <ShoppingIcon height={25} width={25} /> },
        { id: 21, icon: <ShoppingIcon height={25} width={25} /> },
    ];

    const AppBar = () => {
        return (
            <CustomAppBar>
                <IconButton onPress={() => navigation.goBack()}>
                    <BackIcon />
                </IconButton>
                <View style={styles.header}>
                    <Text style={styles.headerTitle}>{t('addcategories')}</Text>
                </View>
                <View style={{ width: 50 }} />
            </CustomAppBar>
        )
    }

    return (
        <View style={CommonStyles.mainContainer}>
            <Loader loading={loading} />
            <SafeAreaView style={{ backgroundColor: Colors.LIGHT_BLUE }} />
            <AppBar />

            <ScrollView style={{ paddingHorizontal: 16, paddingVertical: 10 }}>
                <CustomTextInput
                    value={category}
                    onChangeText={(t: string) => setCategory(t)}
                    label={t('newcategory')}
                    placeholder={t('entercategory')}
                    style={{ marginTop: 20 }}
                />

                <Text style={styles.title}>{t('color')}</Text>
                <View style={styles.wrapicon}>
                    {colorList.map((item) => {
                        return (
                            <TouchableOpacity
                                key={item}
                                onPress={() => setColorCode(item)}
                                style={item == colorCode ? styles.selectedIcon : styles.unselectedIcon}>
                                <View style={[styles.colorBox, { backgroundColor: item }]} />
                            </TouchableOpacity>
                        )
                    })}
                </View>

                <Text style={styles.title}>{t('icons')}</Text>
                <Text style={[styles.subTitle, { marginTop: 0 }]}>{t('finance')}</Text>
                <View style={styles.wrapicon}>
                    {financeIconList.map((item) => {
                        return (
                            <TouchableOpacity
                                key={item.id}
                                onPress={() => setSelectedIcon(item.id)}
                                style={item.id == selectedIcon ? styles.selectedIcon : styles.unselectedIcon}>
                                <View style={styles.icon}>
                                    {item.icon}
                                </View>
                            </TouchableOpacity>
                        )
                    })}
                </View>

                <Text style={styles.subTitle}>{t('food')}</Text>
                <View style={styles.wrapicon}>
                    {foodIconList.map((item) => {
                        return (
                            <TouchableOpacity
                                key={item.id}
                                onPress={() => setSelectedIcon(item.id)}
                                style={item.id == selectedIcon ? styles.selectedIcon : styles.unselectedIcon}>
                                <View style={styles.icon}>
                                    {item.icon}
                                </View>
                            </TouchableOpacity>
                        )
                    })}
                </View>

                <Text style={styles.subTitle}>{t('shopping')}</Text>
                <View style={styles.wrapicon}>
                    {shoppingIconList.map((item) => {
                        return (
                            <TouchableOpacity
                                key={item.id}
                                onPress={() => setSelectedIcon(item.id)}
                                style={item.id == selectedIcon ? styles.selectedIcon : styles.unselectedIcon}>
                                <View style={styles.icon}>
                                    {item.icon}
                                </View>
                            </TouchableOpacity>
                        )
                    })}
                </View>

                <View style={[SpaceStyles.flexRow, SpaceStyles.alignSpaceCenter]}>
                    <Text style={styles.title}>{t('viewyouricon')}</Text>
                    <View style={[styles.icon, { marginLeft: 10, marginTop: 10 }, colorCode && { backgroundColor: colorCode }]}>
                        {financeIconList.map((item) => {
                            if (item.id == selectedIcon) {
                                return item.icon
                            }
                        })}
                        {foodIconList.map((item) => {
                            if (item.id == selectedIcon) {
                                return item.icon
                            }
                        })}
                        {shoppingIconList.map((item) => {
                            if (item.id == selectedIcon) {
                                return item.icon
                            }
                        })}
                    </View>
                </View>

                <View style={styles.bottomButton}>
                    <CustomButton onPress={() => {}} style={styles.bottomButtonSize}>
                        <Text style={styles.bottomButtonText}>{t('save')}</Text>
                    </CustomButton>
                    <View style={{ width: 20 }} />
                    <CustomButton onPress={() => navigation.goBack()} style={styles.bottomButtonSize}>
                        <Text style={styles.bottomButtonText}>{t('cancel')}</Text>
                    </CustomButton>
                </View>
            </ScrollView>
        </View>
    )
}

export default AddCategoriesScreen;

const styles = StyleSheet.create({
    header: {
        flex: 1,
        alignItems: 'center'
    },
    headerTitle: {
        color: Colors.WHITE,
        paddingHorizontal: 8,
        ...Fonts.semiBold22
    },
    title: {
        marginTop: 16, marginBottom: 2, color: Colors.BLACK, ...Fonts.semiBold18
    },
    subTitle: {
        marginTop: 10, marginBottom: 4, color: Colors.BLACK, ...Fonts.medium16
    },
    wrapicon: {
        flexDirection: 'row',
        flexWrap: "wrap",
        // justifyContent: 'space-evenly'
    },
    unselectedIcon: {
        borderWidth: 1, borderColor: 'transparent', padding: 4, borderRadius: 5, alignSelf: 'flex-start'
    },
    selectedIcon: {
        borderWidth: 1, borderColor: Colors.BLACK, padding: 4, borderRadius: 5, alignSelf: 'flex-start'
    },
    colorBox: {
        height: 30, width: 30, borderRadius: 5, alignItems: 'center', justifyContent: 'center'
    },
    icon: {
        height: 35, width: 35, backgroundColor: Colors.LIGHT_GREY, borderRadius: 5, alignItems: 'center', justifyContent: 'center'
    },
    bottomButton: {
        flexDirection: 'row', padding: 20, justifyContent: 'center', marginBottom: 20
    },
    bottomButtonSize: {
        height: 35, width: 90
    },
    bottomButtonText: {
        color: Colors.WHITE, ...Fonts.medium16
    }
})