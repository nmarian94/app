import { useNavigation } from "@react-navigation/native";
import React, { useState } from "react";
import { SafeAreaView, ScrollView, StyleSheet, Text, TouchableOpacity, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import CustomAppBar from "../../Components/CustomAppBar";
import IconButton from "../../Components/IconButton";
import BackIcon from "../../Assets/svg/back-arrow-white.svg";
import CommonStyles from "../styles/CommonStyles";
import LinearGradient from "react-native-linear-gradient";
import PlusIcon from "../../Assets/svg/plus.svg"
import { useTranslation } from "react-i18next";
import RestaurantIcon from "../../Assets/svg/restaurant.svg";
import HospitalIcon from "../../Assets/svg/hospital.svg";
import GroceriesIcon from "../../Assets/svg/groceries.svg";
import GiftIcon from "../../Assets/svg/gift.svg";
import ShoppingIcon from "../../Assets/svg/shopping.svg";
import CloseIcon from "../../Assets/svg/close.svg";
import CharityIcon from "../../Assets/svg/charity.svg";
import InvestIcon from "../../Assets/svg/invest.svg";
import SavingsIcon from "../../Assets/svg/savings.svg";
import TransportationIcon from "../../Assets/svg/transportation.svg";
import EducationIcon from "../../Assets/svg/education.svg";
import Modal from "react-native-modal";
import SpaceStyles from "../styles/SpaceStyles";
import CustomButton from "../../Components/CustomButton";
import Loader from "../../Constants/loader";
import { Colors, Fonts } from "../../Constants";

const CategoriesScreen = () => {
    const { t } = useTranslation();
    const insets = useSafeAreaInsets();
    const navigation = useNavigation();
    const [isVisible, setIsVisible] = useState(false)
    const [loading, setLoading] = useState(false)
    const [categories, setCategories] = useState([])
    const [selectedData, setSelectedData] = useState()

    const AppBar = () => {
        return (
            <CustomAppBar>
                <IconButton onPress={() => navigation.goBack()}>
                    <BackIcon />
                </IconButton>
                <View style={styles.header}>
                    <Text style={styles.headerTitle}>{t('categories')}</Text>
                </View>
                <View style={{ width: 50 }} />
            </CustomAppBar>
        )
    }

    return (
        <View style={CommonStyles.mainContainer}>
            <Loader loading={loading} />
            <SafeAreaView style={{ backgroundColor: Colors.LIGHT_BLUE }} />
            <AppBar />

            <ScrollView>
                <TouchableOpacity
                    onLongPress={() => setIsVisible(true)}
                    style={styles.expensesDataStyle}>
                    <View style={[styles.icon, { backgroundColor: '#FF9900' }]}>
                        <RestaurantIcon />
                    </View>
                    <Text style={styles.dataLabel}>{t('restaurants')}</Text>
                    <Text style={styles.dataPersent}>20%</Text>
                    <Text style={styles.dataPrice}>$15</Text>
                </TouchableOpacity>
                <TouchableOpacity
                    onLongPress={() => setIsVisible(true)}
                    style={styles.expensesDataStyle}>
                    <View style={[styles.icon, { backgroundColor: '#6CA12B' }]}>
                        <HospitalIcon />
                    </View>
                    <Text style={styles.dataLabel}>{t('hospitals')}</Text>
                    <Text style={styles.dataPersent}>10%</Text>
                    <Text style={styles.dataPrice}>$5</Text>
                </TouchableOpacity>
                <TouchableOpacity
                    onLongPress={() => setIsVisible(true)}
                    style={styles.expensesDataStyle}>
                    <View style={[styles.icon, { backgroundColor: '#E8504D' }]}>
                        <GroceriesIcon />
                    </View>
                    <Text style={styles.dataLabel}>{t('groceries')}</Text>
                    <Text style={styles.dataPersent}>20%</Text>
                    <Text style={styles.dataPrice}>$15</Text>
                </TouchableOpacity>
                <TouchableOpacity
                    onLongPress={() => setIsVisible(true)}
                    style={styles.expensesDataStyle}>
                    <View style={[styles.icon, { backgroundColor: '#293377' }]}>
                        <GiftIcon />
                    </View>
                    <Text style={styles.dataLabel}>{t('gifts')}</Text>
                    <Text style={styles.dataPersent}>10%</Text>
                    <Text style={styles.dataPrice}>$5</Text>
                </TouchableOpacity>
                <TouchableOpacity
                    onLongPress={() => setIsVisible(true)}
                    style={styles.expensesDataStyle}>
                    <View style={[styles.icon, { backgroundColor: '#B16668' }]}>
                        <ShoppingIcon />
                    </View>
                    <Text style={styles.dataLabel}>{t('shopping')}</Text>
                    <Text style={styles.dataPersent}>10%</Text>
                    <Text style={styles.dataPrice}>$5</Text>
                </TouchableOpacity>
                <TouchableOpacity
                    onLongPress={() => setIsVisible(true)}
                    style={styles.expensesDataStyle}>
                    <View style={[styles.icon, { backgroundColor: '#634DE8' }]}>
                        <CharityIcon />
                    </View>
                    <Text style={styles.dataLabel}>Charity</Text>
                    <Text style={styles.dataPersent}>20%</Text>
                    <Text style={styles.dataPrice}>$15</Text>
                </TouchableOpacity>
                <TouchableOpacity
                    onLongPress={() => setIsVisible(true)}
                    style={styles.expensesDataStyle}>
                    <View style={[styles.icon, { backgroundColor: '#E84DE2' }]}>
                        <InvestIcon />
                    </View>
                    <Text style={styles.dataLabel}>Invest</Text>
                    <Text style={styles.dataPersent}>10%</Text>
                    <Text style={styles.dataPrice}>$5</Text>
                </TouchableOpacity>
                <TouchableOpacity
                    onLongPress={() => setIsVisible(true)}
                    style={styles.expensesDataStyle}>
                    <View style={[styles.icon, { backgroundColor: '#2381FD' }]}>
                        <SavingsIcon />
                    </View>
                    <Text style={styles.dataLabel}>Savings</Text>
                    <Text style={styles.dataPersent}>20%</Text>
                    <Text style={styles.dataPrice}>$15</Text>
                </TouchableOpacity>
                <TouchableOpacity
                    onLongPress={() => setIsVisible(true)}
                    style={styles.expensesDataStyle}>
                    <View style={[styles.icon, { backgroundColor: '#3C7279' }]}>
                        <TransportationIcon />
                    </View>
                    <Text style={styles.dataLabel}>Transportation</Text>
                    <Text style={styles.dataPersent}>10%</Text>
                    <Text style={styles.dataPrice}>$5</Text>
                </TouchableOpacity>
                <TouchableOpacity
                    onLongPress={() => setIsVisible(true)}
                    style={styles.expensesDataStyle}>
                    <View style={[styles.icon, { backgroundColor: '#7E1181' }]}>
                        <EducationIcon />
                    </View>
                    <Text style={styles.dataLabel}>Education</Text>
                    <Text style={styles.dataPersent}>10%</Text>
                    <Text style={styles.dataPrice}>$5</Text>
                </TouchableOpacity>
            </ScrollView>

            <Modal
                style={{ margin: 0 }}
                animationIn='zoomIn'
                animationOut='zoomOut'
                backdropTransitionOutTiming={0}
                backdropTransitionInTiming={0}
                onBackdropPress={() => setIsVisible(false)}
                onBackButtonPress={() => setIsVisible(false)}
                avoidKeyboard={true}
                isVisible={isVisible}>
                <View style={CommonStyles.modalMainView}>
                    <View style={CommonStyles.modalCell}>
                        <Text style={{ color: Colors.BLACK, ...Fonts.semiBold20 }}>{t('deletecategory')}</Text>
                        <TouchableOpacity onPress={() => setIsVisible(false)}>
                            <CloseIcon />
                        </TouchableOpacity>
                    </View>
                    <View style={{ borderWidth: 0.5, borderColor: Colors.LIGHT_GREY, width: '100%' }} />
                    <View style={{ padding: 20, width: '100%' }}>
                        <View style={SpaceStyles.flexRow}>
                        <View style={[CommonStyles.itemIcon, { backgroundColor: '#FF9900', marginRight: 10 }]}>
                                <RestaurantIcon />
                            </View>
                            <Text style={styles.modalText}>Restaurants</Text>
                        </View>
                        <Text style={[styles.modalText, { marginTop: 10, marginBottom: 20 }]}>{t('areyousureyouwanttodeletethiscategory')}</Text>
                        <View style={styles.modalButton}>
                        <CustomButton
                                onPress={() => setIsVisible(false)}
                                colors={[Colors.RED, Colors.RED]}
                                style={styles.modalButtonSize}>
                                <Text style={styles.modalButtonText}>{t('delete')}</Text>
                            </CustomButton>
                            <View style={{ width: 10 }} />
                            <CustomButton
                                onPress={() => setIsVisible(false)}
                                style={styles.modalButtonSize}>
                                <Text style={styles.modalButtonText}>{t('cancel')}</Text>
                            </CustomButton>

                        </View>
                    </View>
                </View>
            </Modal>

            <LinearGradient
                colors={[Colors.BLUE, Colors.LIGHT_BLUE]}
                start={{ x: 0, y: 1 }} end={{ x: 0, y: 0 }}
                style={[styles.floating, { bottom: 20 + insets.bottom, right: 20 + insets.right }]}>
                <TouchableOpacity
                    onPress={() => navigation.navigate('AddCategoriesScreen' as never)}
                    style={styles.floatingButton}>
                    <PlusIcon height={20} width={20} />
                </TouchableOpacity>
            </LinearGradient>
        </View>
    )
}

export default CategoriesScreen;

const styles = StyleSheet.create({
    header: {
        flex: 1,
        alignItems: 'center'
    },
    headerTitle: {
        color: Colors.WHITE,
        paddingHorizontal: 8,
        ...Fonts.semiBold22
    },
    expensesDataStyle: {
        flexDirection: 'row',
        alignItems: 'center',
        marginHorizontal: 10,
        marginTop: 10,
        padding: 10,
        borderRadius: 20,
        backgroundColor: Colors.WHITE,
        shadowColor: "#000",
        shadowOffset: {
            width: 0,
            height: 1,
        },
        shadowOpacity: 0.20,
        shadowRadius: 1.41,
        elevation: 2,
    },
    icon: {
        height: 40,
        width: 40,
        borderRadius: 30,
        alignItems: 'center',
        justifyContent: 'center'
    },
    dataLabel: {
        flex: 1,
        paddingLeft: 10,
        color: Colors.BLACK,
        textTransform: 'capitalize',
        ...Fonts.semiBold16
    },
    dataPersent: {
        color: Colors.BLACK, paddingHorizontal: 10, ...Fonts.regular16
    },
    dataPrice: {
        color: Colors.BLACK, ...Fonts.semiBold16
    },
    modalButton: {
        flexDirection: 'row', justifyContent: 'center'
    },
    modalButtonSize: {
        height: 30, width: 90
    },
    modalText: {
        color: Colors.BLACK, ...Fonts.semiBold16
    },
    modalButtonText: {
        color: Colors.WHITE, ...Fonts.medium14
    },
    floating: {
        width: 60,
        height: 60,
        borderRadius: 30,
        position: 'absolute',
        alignItems: 'center',
        justifyContent: 'center'
    },
    floatingButton: {
        width: 60,
        height: 60,
        borderRadius: 30,
        alignItems: 'center',
        justifyContent: 'center'
    }
})