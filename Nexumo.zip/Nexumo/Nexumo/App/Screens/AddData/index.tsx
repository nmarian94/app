import React, { useState } from "react";
import { SafeAreaView, ScrollView, StyleSheet, Text, TouchableOpacity, View } from "react-native";
import CustomAppBar from "../../Components/CustomAppBar";
import IconButton from "../../Components/IconButton";
import DrawerIcon from "../../Assets/svg/drawer.svg";
import CalendarIcon from "../../Assets/svg/calendar.svg";
import DownArrowIcon from "../../Assets/svg/down-arrow.svg";
import DollarIcon from "../../Assets/svg/dollar.svg";
import { useTranslation } from "react-i18next";
import { useNavigation } from "@react-navigation/native";
import CustomButton from "../../Components/CustomButton";
import ExpensesTab from "./Tabs/ExpensesTab";
import IncomeTab from "./Tabs/IncomeTab";
import CommonStyles from "../styles/CommonStyles";
import { useDrawerStatus } from "@react-navigation/drawer";
import SelectAccountModal from "../../Components/SelectAccountModal";
import CalendarModal from "../../Components/CalendarModal";
import { Colors, Fonts } from "../../Constants";

const AddDataScreen = (props: any) => {
    const { params } = props.route;
    const { t, i18n } = useTranslation();
    const navigation = useNavigation();
    const [tab, setTab] = useState(params?.tab ?? 'expenses');
    const [isVisible, setIsVisible] = useState(false)
    const isDrawerOpen = useDrawerStatus() === 'open';
    const [showCalendars, setShowCalendars] = useState(false);
    const [selectedDate, setSelectedDate] = useState({});

    const AppBar = () => {
        return (
            <CustomAppBar>
                <IconButton onPress={() => isDrawerOpen ? navigation.closeDrawer() : navigation.openDrawer()}>
                    <DrawerIcon height={26} width={26} />
                </IconButton>
                <View style={CommonStyles.header}>
                    <TouchableOpacity
                        onPress={() => setIsVisible(true)}
                        style={CommonStyles.headerTitleWrapper}>
                        <DollarIcon height={16} width={16} />
                        <Text style={CommonStyles.headerTitle}>{t('total')}</Text>
                        <DownArrowIcon height={12} width={12} />
                    </TouchableOpacity>
                    <Text style={CommonStyles.headerSubTitle}>{'\$1200'}</Text>
                </View>
                <IconButton onPress={() => setShowCalendars(true)}>
                    <CalendarIcon height={26} width={26} />
                </IconButton>
            </CustomAppBar>
        )
    }

    return (
        <View style={CommonStyles.mainContainer}>
            <SafeAreaView style={{ backgroundColor: Colors.LIGHT_BLUE }} />
            <AppBar />
            <ScrollView>
                <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-evenly', marginVertical: 16 }}>
                    <CustomButton
                        onPress={() => setTab('expenses')}
                        style={[styles.buttonStyle, tab !== 'expenses' && { borderWidth: 1, borderColor: Colors.BLUE }]}
                        colors={tab == 'expenses' ? [Colors.BLUE, Colors.LIGHT_BLUE] : [Colors.WHITE, Colors.WHITE]}>
                        <Text style={[styles.buttonText, { color: tab == 'expenses' ? Colors.WHITE : Colors.BLUE }]}>{t('expenses')}</Text>
                    </CustomButton>
                    <CustomButton
                        onPress={() => setTab('income')}
                        style={[styles.buttonStyle, tab !== 'income' && { borderWidth: 1, borderColor: Colors.BLUE }]}
                        colors={tab == 'income' ? [Colors.BLUE, Colors.LIGHT_BLUE] : [Colors.WHITE, Colors.WHITE]}>
                        <Text style={[styles.buttonText, { color: tab == 'income' ? Colors.WHITE : Colors.BLUE }]}>{t('income')}</Text>
                    </CustomButton>
                </View>
                {tab === 'expenses' ? <ExpensesTab params={params} /> : <IncomeTab params={params} />}
            </ScrollView>
            <SelectAccountModal isVisible={isVisible} setIsVisible={setIsVisible} />

            <CalendarModal showCalendars={showCalendars} setShowCalendars={setShowCalendars} setSelectedDate={setSelectedDate} />
        </View>
    )
}

export default AddDataScreen;

const styles = StyleSheet.create({
    mainContainer: {
        flex: 1,
        backgroundColor: Colors.WHITE
    },
    buttonStyle: {
        height: 40, 
        width: 130
    },
    buttonText: {
        ...Fonts.semiBold16
    },
})