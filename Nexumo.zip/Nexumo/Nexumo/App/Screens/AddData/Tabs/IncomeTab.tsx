import React, { useState } from "react";
import { StyleSheet, Text, View } from "react-native";
import CustomTextInput from "../../../Components/CustomTextInput";
import Chip from "../../../Components/Chip";
import SalaryIcon from "../../../Assets/svg/salary.svg";
import InterestIcon from "../../../Assets/svg/interest.svg";
import CashbackIcon from "../../../Assets/svg/cashback.svg";
import SalesIcon from "../../../Assets/svg/sales.svg";
import CustomButton from "../../../Components/CustomButton";
import { useTranslation } from "react-i18next";
import { useNavigation } from "@react-navigation/native";
import Loader from "../../../Constants/loader";
import { Colors, Fonts } from "../../../Constants";

const IncomeTab = () => {
    const { t } = useTranslation();
    const navigation = useNavigation()
    const [amount, setAmount] = useState('')
    const [title, setTitle] = useState('')
    const [categoryId, setCategoryId] = useState(0)
    const [loading, setLoading] = useState(false)

    const categories = [
        {
            icon: <SalaryIcon height={16} width={16} />,
            label: 'Salary',
            iconColor: '#B64DE8',
        },
        {
            icon: <InterestIcon height={16} width={16} />,
            label: 'Interest',
            iconColor: '#45C9C1',
        },
        {
            icon: <CashbackIcon height={16} width={16} />,
            label: 'Cashback',
            iconColor: '#FF0000',
        },
        {
            icon: <SalesIcon height={16} width={16} />,
            label: 'Sales',
            iconColor: '#1757FB',
        }
    ];

    return (
        <View style={styles.mainContainer}>
            <Loader loading={loading} />
            <View style={{ height: 10 }} />
            <CustomTextInput
                value={amount}
                onChangeText={(t: string) => setAmount(t)}
                label={t('amount')}
                placeholder={t('enteramount')}
                keyboardType={'numeric'}
            />
            <View style={{ height: 20 }} />
            <CustomTextInput
                value={title}
                onChangeText={(t: string) => setTitle(t)}
                label={t('title')}
                placeholder={t('entertitle')}
            />
            <View style={{ height: 20 }} />
            <View style={styles.inputContainer}>
                <View style={styles.labelContainer}>
                    <Text style={styles.labelStyle}>{t('categories')}</Text>
                </View>
                {/* <Text style={{ color: GREY, ...Constants.Fonts.medium17, marginTop: 5 }}>{t('shopping')}</Text> */}
                <View style={{ marginTop: 8, flexDirection: 'row', flexWrap: "wrap" }}>
                    {
                        categories.map((item, index) => {
                            return (
                                <Chip
                                    iconColor={item.iconColor}
                                    label={item.label}
                                    fullColor={categoryId === index ? item.iconColor : '#FFFFFF'}
                                    labelStyle={{ color: categoryId === index ? Colors.WHITE : Colors.BLACK }}
                                    onPress={() => setCategoryId(index)}>
                                    {item.icon}
                                </Chip>
                            )
                        })
                    }
                </View>

                <View style={{ flex: 1 }} />
                <CustomButton style={styles.categoriesButton}>
                    <Text style={{ color: Colors.WHITE, ...Fonts.medium14 }}>{t('addcategories')}</Text>
                </CustomButton>
            </View>

            <View style={styles.bottomButton}>
                <CustomButton
                    onPress={() => { }}
                    style={styles.bottomButtonSize}>
                    <Text style={styles.bottomButtonText}>{t('save')}</Text>
                </CustomButton>
                <View style={{ width: 10 }} />
                <CustomButton onPress={() => navigation.goBack()} style={styles.bottomButtonSize}>
                    <Text style={styles.bottomButtonText}>{t('cancel')}</Text>
                </CustomButton>
            </View>
        </View>
    )
}

export default IncomeTab;

const styles = StyleSheet.create({
    mainContainer: {
        marginHorizontal: 16
    },
    labelContainer: {
        backgroundColor: "white", // Same color as background
        alignSelf: "flex-start", // Have View be same width as Text inside
        paddingHorizontal: 6, // Amount of spacing between border and first/last letter
        marginStart: 16, // How far right do you want the label to start
        zIndex: 1, // Label must overlap border
        elevation: 1, // Needed for android
        shadowColor: "white", // Same as background color because elevation: 1 creates a shadow that we don't want
        position: "absolute", // Needed to be able to precisely overlap label with border
        top: -10, // Vertical position of label. Eyeball it to see where label intersects border.
    },
    labelStyle: {
        color: Colors.BLUE,
        ...Fonts.semiBold15
    },
    inputContainer: {
        minHeight: 250,
        justifyContent: 'flex-start',
        borderWidth: 1, // Create border
        borderColor: Colors.LIGHT_GREY,
        borderRadius: 8, // Not needed. Just make it look nicer.
        padding: 5, // Also used to make it look nicer
        zIndex: 0, // Ensure border has z-index of 0
    },
    categoriesButton: {
        height: 30,
        width: 148,
        alignSelf: 'center',
        marginBottom: 10
    },
    bottomButton: {
        flexDirection: 'row',
        padding: 20,
        justifyContent: 'center'
    },
    bottomButtonSize: {
        height: 35,
        width: 90
    },
    bottomButtonText: {
        color: Colors.WHITE,
        ...Fonts.medium16
    }
})