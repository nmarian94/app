import React, { useEffect, useState } from "react";
import { Image, SafeAreaView, ScrollView, StyleSheet, Text, View } from "react-native";
import BackIcon from "../../Assets/svg/back-arrow-white.svg";
import IconButton from "../../Components/IconButton";
import CustomAppBar from "../../Components/CustomAppBar";
import { useNavigation } from "@react-navigation/native";
import CommonStyles from "../styles/CommonStyles";
import SpaceStyles from "../styles/SpaceStyles";
import RestaurantIcon from "../../Assets/svg/restaurant.svg";
import GroceriesIcon from "../../Assets/svg/groceries.svg";
import GiftIcon from "../../Assets/svg/gift.svg";
import CloseIcon from "../../Assets/svg/close.svg";
import ShoppingIcon from "../../Assets/svg/shopping.svg";
import CustomButton from "../../Components/CustomButton";
import { useTranslation } from "react-i18next";
import Loader from "../../Constants/loader";
import { Colors, Fonts } from "../../Constants";

const AllTransactionsScreen = () => {
    const navigation = useNavigation();
    const { t } = useTranslation();
    const [loading, setLoading] = useState(false)

    const AppBar = () => {
        return (
            <CustomAppBar>
                <IconButton onPress={() => navigation.goBack()}>
                    <BackIcon />
                </IconButton>
                <View style={styles.header}>
                    <Text style={styles.headerTitle}>{t('alltransactions')}</Text>
                </View>
                <View style={{ width: 50 }} />
            </CustomAppBar>
        )
    }

    return (
        <View style={CommonStyles.mainContainer}>
            <Loader loading={loading} />
            <SafeAreaView style={{ backgroundColor: Colors.LIGHT_BLUE }} />
            <AppBar />

            <ScrollView>
                <View style={styles.transactionItem}>
                    <View style={styles.budgetDataStyle}>
                        <View style={[CommonStyles.itemIcon, { backgroundColor: '#E8504D' }]}>
                            <GroceriesIcon />
                        </View>
                        <View style={{ flex: 1 }}>
                            <Text style={styles.dataLabel}>Starbucks</Text>
                            <Text style={styles.dataSubLabel}>{t('spent')}: $4</Text>
                        </View>
                        <Text style={{ color: Colors.GREY, ...Fonts.regular12 }}>1 day ago</Text>
                    </View>
                </View>
                <View style={styles.transactionItem}>
                    <View style={styles.budgetDataStyle}>
                        <View style={[CommonStyles.itemIcon, { backgroundColor: '#293377' }]}>
                            <GiftIcon />
                        </View>
                        <View style={{ flex: 1 }}>
                            <Text style={styles.dataLabel}>Raj Thaal Restaurant</Text>
                            <Text style={styles.dataSubLabel}>{t('spent')}: $3</Text>
                        </View>
                        <Text style={{ color: Colors.GREY, ...Fonts.regular12 }}>Jun 30</Text>
                    </View>
                </View>
                <View style={styles.transactionItem}>
                    <View style={styles.budgetDataStyle}>
                        <View style={[CommonStyles.itemIcon, { backgroundColor: '#293377' }]}>
                            <GiftIcon />
                        </View>
                        <View style={{ flex: 1 }}>
                            <Text style={styles.dataLabel}>Cafe coffee Day</Text>
                            <Text style={styles.dataSubLabel}>{t('spent')}: $2</Text>
                        </View>
                        <Text style={{ color: Colors.GREY, ...Fonts.regular12 }}>March 3</Text>
                    </View>
                </View>
                <View style={styles.transactionItem}>
                    <View style={styles.budgetDataStyle}>
                        <View style={[CommonStyles.itemIcon, { backgroundColor: '#E8504D' }]}>
                            <GroceriesIcon />
                        </View>
                        <View style={{ flex: 1 }}>
                            <Text style={styles.dataLabel}>Jay Hotel</Text>
                            <Text style={styles.dataSubLabel}>{t('spent')}: $2</Text>
                        </View>
                        <Text style={{ color: Colors.GREY, ...Fonts.regular12 }}>Jan 23</Text>
                    </View>
                </View>
                <View style={styles.transactionItem}>
                    <View style={styles.budgetDataStyle}>
                        <View style={[CommonStyles.itemIcon, { backgroundColor: '#E8504D' }]}>
                            <GroceriesIcon />
                        </View>
                        <View style={{ flex: 1 }}>
                            <Text style={styles.dataLabel}>D-Mart</Text>
                            <Text style={styles.dataSubLabel}>{t('spent')}: $1</Text>
                        </View>
                        <Text style={{ color: Colors.GREY, ...Fonts.regular12 }}>Jan 23</Text>
                    </View>
                </View>
                <View style={styles.transactionItem}>
                    <View style={styles.budgetDataStyle}>
                        <View style={[CommonStyles.itemIcon, { backgroundColor: '#E8504D' }]}>
                            <GroceriesIcon />
                        </View>
                        <View style={{ flex: 1 }}>
                            <Text style={styles.dataLabel}>City Hospital</Text>
                            <Text style={styles.dataSubLabel}>{t('spent')}: $2</Text>
                        </View>
                        <Text style={{ color: Colors.GREY, ...Fonts.regular12 }}>Jan 23</Text>
                    </View>
                </View>
                <View style={styles.transactionItem}>
                    <View style={styles.budgetDataStyle}>
                        <View style={[CommonStyles.itemIcon, { backgroundColor: '#E8504D' }]}>
                            <GroceriesIcon />
                        </View>
                        <View style={{ flex: 1 }}>
                            <Text style={styles.dataLabel}>Vegetables</Text>
                            <Text style={styles.dataSubLabel}>{t('spent')}: $5</Text>
                        </View>
                        <Text style={{ color: Colors.GREY, ...Fonts.regular12 }}>Jan 23</Text>
                    </View>
                </View>
                <View style={styles.transactionItem}>
                    <View style={styles.budgetDataStyle}>
                        <View style={[CommonStyles.itemIcon, { backgroundColor: '#293377' }]}>
                            <GiftIcon />
                        </View>
                        <View style={{ flex: 1 }}>
                            <Text style={styles.dataLabel}>Westside</Text>
                            <Text style={styles.dataSubLabel}>{t('spent')}: $3</Text>
                        </View>
                        <Text style={{ color: Colors.GREY, ...Fonts.regular12 }}>Jun 30</Text>
                    </View>
                </View>
                <View style={styles.transactionItem}>
                    <View style={styles.budgetDataStyle}>
                        <View style={[CommonStyles.itemIcon, { backgroundColor: '#293377' }]}>
                            <GiftIcon />
                        </View>
                        <View style={{ flex: 1 }}>
                            <Text style={styles.dataLabel}>Trends</Text>
                            <Text style={styles.dataSubLabel}>{t('spent')}: $2</Text>
                        </View>
                        <Text style={{ color: Colors.GREY, ...Fonts.regular12 }}>March 3</Text>
                    </View>
                </View>
            </ScrollView>
        </View>
    )
}

export default AllTransactionsScreen;

const styles = StyleSheet.create({
    mainContainer: {
        flex: 1
    },
    header: {
        flex: 1,
        alignItems: 'center'
    },
    headerTitle: {
        color: Colors.WHITE,
        paddingHorizontal: 8,
        ...Fonts.semiBold22
    },
    transactionItem: {
        paddingHorizontal: 20, borderBottomWidth: 1, paddingBottom: 10, borderColor: Colors.LIGHT_GREY
    },
    budgetDataStyle: {
        flexDirection: 'row',
        alignItems: 'center',
        paddingTop: 10,
    },
    dataLabel: {
        paddingHorizontal: 10,
        color: Colors.BLACK,
        ...Fonts.semiBold16
    },
    dataSubLabel: {
        color: Colors.GREY, paddingLeft: 10, ...Fonts.regular14
    },
    budgetUsed: {
        height: 30, borderWidth: 2, borderColor: Colors.BLUE, width: 100, borderRadius: 50, alignItems: 'center', justifyContent: 'center'
    }
})