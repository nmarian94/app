import React, { useState } from "react";
import { SafeAreaView, StyleSheet, Text, TouchableOpacity, View } from "react-native";
import LinearGradient from "react-native-linear-gradient";
import Logo from "../../Assets/svg/logoWithText.svg";
import GoogleIcon from "../../Assets/svg/google.svg";
import FacebookIcon from "../../Assets/svg/facebook.svg";
import GmailIcon from "../../Assets/svg/gmail.svg";
import AppleIcon from "../../Assets/svg/apple.svg";
import { useNavigation } from "@react-navigation/native";
import { useTranslation } from "react-i18next";
import Loader from "../../Constants/loader";
import { Colors, Fonts } from "../../Constants";

export default function SocialLoginScreen() {
    const { t } = useTranslation();
    const navigation = useNavigation();
    const [loading, setLoading] = useState(false)

    const googleSignIn = async () => {
        navigation.navigate('DrawerNavigation' as never)
    };

    async function onAppleButtonPress() {
        navigation.navigate('DrawerNavigation' as never)
    }

    const handleFacebookLogin = async () => {
        navigation.navigate('DrawerNavigation' as never)
    }

    return (
        <LinearGradient
            colors={[Colors.BLUE, Colors.LIGHT_BLUE]}
            start={{ x: 0, y: 1 }} end={{ x: 0, y: 0 }}
            style={styles.mainContainer}
        >
            <Loader loading={loading} />
            <SafeAreaView />
            <View style={{ height: '10%' }} />
            <Logo height={'20%'} />
            <Text style={styles.title}>Sign up below to create a secure account.</Text>
            <View style={{ width: '100%', flexDirection: 'row', justifyContent: 'space-between' }}>
                <TouchableOpacity onPress={googleSignIn} style={styles.button}>
                    <View style={{ width: 50, alignItems: 'center' }}>
                        <GoogleIcon />
                    </View>
                </TouchableOpacity>
                <TouchableOpacity onPress={handleFacebookLogin} style={styles.button}>
                    <View style={{ width: 50, alignItems: 'center' }}>
                        <FacebookIcon />
                    </View>
                </TouchableOpacity>
                <TouchableOpacity
                    onPress={() => navigation.navigate('RegisterScreen' as never)}
                    style={styles.button}>
                    <View style={{ width: 50, alignItems: 'center' }}>
                        <GmailIcon />
                    </View>
                </TouchableOpacity>
            </View>
            <TouchableOpacity onPress={onAppleButtonPress} style={styles.appleButton}>
                <View style={{ marginRight: 10, marginBottom: 5 }}>
                    <AppleIcon />
                </View>
                <Text style={styles.text}>Sign in with Apple</Text>
            </TouchableOpacity>
            <Text style={styles.text}>{t('alreadyhaveanaccount')}
                <Text
                    onPress={() => navigation.navigate('LoginScreen' as never)}
                    style={{ ...Fonts.bold18 }}>{t('login')}</Text>
            </Text>
            <View style={{ height: 20 }} />
            <Text style={styles.desc}>{t('bysigninguporconnecting')}
                <Text style={{ ...Fonts.bold15 }}> {t('termsofservice')} </Text>
                {t('andacknowledgeour')}
                <Text style={{ ...Fonts.bold15 }}> {t('privacypolicy')} </Text>
                {t('describinghow')}</Text>
        </LinearGradient>
    )
}

const styles = StyleSheet.create({
    mainContainer: {
        flex: 1, alignItems: 'center', padding: 16
    },
    title: {
        color: Colors.WHITE,
        textAlign: 'center',
        marginVertical: 20,
        ...Fonts.bold28
    },
    button: {
        height: 45,
        borderRadius: 50,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: Colors.WHITE,
        paddingHorizontal: '8%'
    },
    appleButton: {
        flexDirection: 'row',
        marginVertical: 20,
        height: 45,
        borderRadius: 50,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: Colors.BLACK,
        paddingHorizontal: '8%'
    },
    text: {
        color: Colors.WHITE,
        textAlign: 'center',
        ...Fonts.medium18
    },
    desc: {
        color: Colors.WHITE,
        textAlign: 'center',
        ...Fonts.medium15
    }
})