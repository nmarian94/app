import React, { useState } from "react";
import { StyleSheet, Text, View, TouchableOpacity } from "react-native";
import BackButton from "../../Components/BackButton";
import Logo from "../../Assets/svg/logoWithText.svg";
import ArrowRight from "../../Assets/svg/arrow-right-white.svg";
import { useNavigation } from "@react-navigation/native";
import CustomTextInput from "../../Components/CustomTextInput";
import CustomButton from "../../Components/CustomButton";
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useTranslation } from "react-i18next";
import Loader from "../../Constants/loader";
import { Colors, Fonts } from "../../Constants";

export default function LoginScreen() {
    const { t } = useTranslation();
    const navigation = useNavigation();
    const insets = useSafeAreaInsets();
    const [loading, setLoading] = useState(false)
    const [email, setEmail] = useState('')
    const [password, setPassword] = useState('')
    const [check, setCheck] = useState(false)
    const [emailError, setEmailError] = useState(false)
    const [passwordError, setPasswordError] = useState(false)
    const [checkError, setCheckError] = useState(false)
    const [secureTextEntry, setSecureTextEntry] = useState(true)

    const handleLogin = () => {
        navigation.navigate('DrawerNavigation' as never)
    }

    return (
        <KeyboardAwareScrollView style={styles.mainContainer}>
            <Loader loading={loading} />
            <View style={{ margin: 20 }}>
                <View style={{ height: insets.top - 20 }} />
                <BackButton onPress={() => navigation.goBack()} style={{ paddingHorizontal: 0 }} />
                <View style={{ height: 10 }} />
                <Logo height={110} width={100} />
                <View style={{ height: 10 }} />
                <Text style={styles.title}>{t('welcome')}</Text>
                <View style={{ height: 5 }} />
                <Text style={styles.subTitle}>{t('signintocontinue')}</Text>
                <View style={{ height: 10 }} />
                <CustomTextInput
                    autoCapitalize={"none"}
                    value={email}
                    onChangeText={(t: string) => setEmail(t)}
                    label={t('email')}
                    placeholder={t('enteremail')}
                    style={styles.textInputStyle} />
                {emailError && <Text style={styles.error}>{'required'}</Text>}
                <CustomTextInput
                    value={password}
                    onChangeText={(t: string) => setPassword(t)}
                    keyboardType={'email-address'}
                    label={t('password')}
                    placeholder={t('enterpassword')}
                    secureTextEntry={secureTextEntry}
                    showIcon={true}
                    onPress={() => setSecureTextEntry(!secureTextEntry)}
                    style={styles.textInputStyle} />
                {passwordError && <Text style={styles.error}>{'required'}</Text>}

                <View style={styles.checkWrapper}>
                    <TouchableOpacity onPress={() => setCheck(!check)} style={{ flexDirection: 'row', alignItems: 'center' }}>
                        <View style={[styles.borderRound, checkError && { borderColor: Colors.RED }]}>
                            {check && <View style={styles.fillRound} />}
                        </View>
                    </TouchableOpacity>
                    <Text style={{ color: Colors.BLUE, ...Fonts.nunitoRegular14 }}>{t('rememberme')}</Text>
                    <View style={{ flex: 1 }} />
                    <TouchableOpacity>
                        <Text style={{ color: Colors.RED, ...Fonts.nunitoRegular14 }}>{t('forgotpassword')}</Text>
                    </TouchableOpacity>
                </View>
                <CustomButton
                    onPress={() => handleLogin()}
                    style={{ marginHorizontal: 20, marginVertical: 30 }}>
                    <Text style={styles.buttonText}>{t('login')}</Text>
                    <ArrowRight />
                </CustomButton>

                <Text style={styles.textButton}>{t('donthaveanaccount')}
                    <Text
                        onPress={() => navigation.navigate('RegisterScreen' as never)}
                        style={{ ...Fonts.bold18 }}>{t('signup')}</Text>
                </Text>
            </View>
        </KeyboardAwareScrollView>
    )
}

const styles = StyleSheet.create({
    mainContainer: {
        flex: 1,
        backgroundColor: Colors.WHITE
    },
    title: {
        color: Colors.BLACK,
        ...Fonts.bold30
    },
    subTitle: {
        color: Colors.GREY,
        ...Fonts.medium17
    },
    error: {
        color: Colors.RED,
        ...Fonts.regular16
    },
    textInputStyle: {
        marginTop: 20,
        marginBottom: 5
    },
    buttonText: {
        color: Colors.WHITE,
        marginRight: 10,
        ...Fonts.semiBold20
    },
    textButton: {
        color: Colors.BLUE,
        textAlign: 'center',
        ...Fonts.medium18
    },
    checkWrapper: {
        flexDirection: 'row',
        alignItems: 'center',
        marginVertical: 12
    },
    borderRound: {
        height: 20,
        width: 20,
        borderWidth: 1,
        borderRadius: 20,
        borderColor: Colors.BLUE,
        alignItems: 'center',
        justifyContent: 'center',
        marginRight: 8
    },
    fillRound: {
        height: 12,
        width: 12,
        borderRadius: 20,
        backgroundColor: Colors.BLUE
    }
})