import React, { useEffect } from "react";
import { View } from "react-native";
import LinearGradient from "react-native-linear-gradient";
import Logo from "../../Assets/svg/logoWithText.svg";
import Spiral from "../../Assets/svg/spiral.svg";
import Splash from "../../Assets/svg/splash.svg";
import { useNavigation } from "@react-navigation/native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { BaseStyle, Colors } from "../../Constants";

const HEIGHT = (BaseStyle.DEVICE_HEIGHT / 100)
const WIDTH = (BaseStyle.DEVICE_WIDTH / 100)

export default function SplashScreen() {
    const navigation = useNavigation();
    const insets = useSafeAreaInsets();

    useEffect(() => {
        setTimeout(() => {
            navigation.navigate('WelcomeScreen' as never);
        }, 1500);
    }, [])

    return (
        <LinearGradient
            colors={[Colors.LIGHT_BLUE, Colors.BLUE]}
            start={{ x: 0, y: 1 }} end={{ x: 0, y: 0 }}
            style={{ flex: 1, alignItems: 'center' }}
        >
            <Splash height={'100%'} width={'100%'} />
            <View style={{ position: 'absolute', bottom: 20 + insets.bottom }}>
                <Logo width={WIDTH * 30} />
            </View>
        </LinearGradient>
    )
}