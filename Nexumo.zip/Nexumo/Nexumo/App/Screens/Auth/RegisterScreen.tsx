import React, { useState } from "react";
import { StyleSheet, Text, View, Platform } from "react-native";
import BackButton from "../../Components/BackButton";
import Logo from "../../Assets/svg/logoWithText.svg";
import ArrowRight from "../../Assets/svg/arrow-right-white.svg";
import { useNavigation } from "@react-navigation/native";
import CustomTextInput from "../../Components/CustomTextInput";
import CustomButton from "../../Components/CustomButton";
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useTranslation } from "react-i18next";
import Loader from "../../Constants/loader";
import { Colors, Fonts } from "../../Constants";

const isIos = Platform.OS === "ios"

export default function RegisterScreen() {
    const { t } = useTranslation();
    const navigation = useNavigation();
    const insets = useSafeAreaInsets();
    const [name, setName] = useState('')
    const [email, setEmail] = useState('')
    const [password, setPassword] = useState('')
    const [confirmPassword, setConfirmPassword] = useState('')
    const [loading, setLoading] = useState(false)
    const [nameError, setNameError] = useState(false)
    const [emailError, setEmailError] = useState(false)
    const [passwordError, setPasswordError] = useState(false)
    const [confirmPasswordError, setConfirmPasswordError] = useState(false)

    const handleRegister = () => {
        navigation.navigate('DrawerNavigation' as never)
    }

    return (
        <KeyboardAwareScrollView style={styles.mainContainer}>
            <Loader loading={loading} />
            <View style={{ margin: 20 }}>
                <View style={{ height: insets.top - 20 }} />
                <BackButton onPress={() => navigation.goBack()} style={{ paddingHorizontal: 0 }} />
                <View style={{ height: 10 }} />
                <Logo height={110} width={100} />
                <View style={{ height: 16 }} />
                <Text style={styles.title}>{t('signup')}!</Text>
                <View style={{ height: 5 }} />
                <Text style={styles.subTitle}>{t('createanewaccount')}</Text>
                <View style={{ height: 16 }} />
                <CustomTextInput
                    value={name}
                    onChangeText={(t: string) => setName(t)}
                    label={t('yourname')}
                    placeholder={t('enterfullname')}
                    style={styles.textInputStyle} />
                {nameError && <Text style={styles.error}>{'required'}</Text>}
                <CustomTextInput
                    value={email}
                    onChangeText={(t: string) => setEmail(t)}
                    keyboardType={'email-address'}
                    label={t('email')}
                    placeholder={t('enteremail')}
                    style={styles.textInputStyle} />
                {emailError && <Text style={styles.error}>{'required'}</Text>}
                <CustomTextInput
                    value={password}
                    onChangeText={(t: string) => setPassword(t)}
                    label={t('password')}
                    placeholder={t('enterpassword')}
                    secureTextEntry={true}
                    style={styles.textInputStyle} />
                {passwordError && <Text style={styles.error}>{'required'}</Text>}
                <CustomTextInput
                    value={confirmPassword}
                    onChangeText={(t: string) => setConfirmPassword(t)}
                    label={t('confirmpassword')}
                    placeholder={t('enterpassword')}
                    secureTextEntry={true}
                    style={styles.textInputStyle} />
                {confirmPasswordError && <Text style={styles.error}>{'required'}</Text>}
                <CustomButton
                    onPress={() => handleRegister()}
                    style={{ marginHorizontal: 20, marginVertical: 30 }}>
                    <Text style={styles.buttonText}>{t('register')}</Text>
                    <ArrowRight />
                </CustomButton>

                <Text style={styles.textButton}>{t('alreadyhaveanaccount')}
                    <Text
                        onPress={() => navigation.navigate('LoginScreen' as never)}
                        style={{ ...Fonts.bold18 }}>{t('signin')}</Text>
                </Text>
            </View>
        </KeyboardAwareScrollView>
    )
}

const styles = StyleSheet.create({
    mainContainer: {
        flex: 1,
        backgroundColor: Colors.WHITE
    },
    title: {
        color: Colors.BLACK,
        ...Fonts.bold30
    },
    subTitle: {
        color: Colors.GREY,
        ...Fonts.medium17
    },
    error: {
        color: Colors.RED,
        ...Fonts.regular16
    },
    textInputStyle: {
        marginTop: 20,
        marginBottom: 5
    },
    buttonText: {
        color: Colors.WHITE,
        marginRight: 10,
        ...Fonts.semiBold20
    },
    textButton: {
        color: Colors.BLUE,
        textAlign: 'center',
        ...Fonts.medium18
    }
})