import React, { useRef } from "react";
import { Image, SafeAreaView, StyleSheet, Text, TouchableOpacity, View } from "react-native";
import Image1 from '../../Assets/images/image1.png';
import Image2 from '../../Assets/images/image2.png';
import Image3 from '../../Assets/images/image3.png';
import ArrowRight from '../../Assets/svg/arrow-right.svg';
import LinearGradient from "react-native-linear-gradient";
import Swiper from "react-native-swiper";
import { useNavigation } from "@react-navigation/native";
import { useTranslation } from "react-i18next";
import { Colors, Fonts } from "../../Constants";

export default function WelcomeScreen() {
    const { t } = useTranslation();
    const navigation = useNavigation();
    const swiperRef = useRef<Swiper>(null);
    const totalSlides = 3;
    const handleNextButton = () => {
        if (swiperRef.current) {
            const nextIndex = swiperRef.current.state.index + 1;
            if (nextIndex < totalSlides) {
                swiperRef.current.scrollBy(1);
            } else {
                navigation.navigate('SocialLoginScreen' as never);
            }
        }
    };

    return (
        <LinearGradient
            colors={[Colors.LIGHT_BLUE, Colors.BLUE]}
            start={{ x: 0, y: 1 }} end={{ x: 0, y: 0 }}
            style={{ flex: 1 }}
        >
            <Swiper
                ref={swiperRef}
                activeDotColor={Colors.WHITE}
                index={0}
                loop={false}
                horizontal={true}
                autoplay={false}
                dotStyle={styles.dot}
                activeDotStyle={[styles.dot, { backgroundColor: Colors.WHITE }]}
            >
                <>
                    <View style={styles.topContainer}>
                        <View style={styles.logoImageWrapper}>
                            <View style={styles.logoSpace} />
                            <View style={styles.imageView}>
                                <Image source={Image1} style={{ height: '100%', width: '100%' }} />
                            </View>
                        </View>
                        <View style={styles.logoView}>
                            <Text style={styles.logo}>WALLETUS</Text>
                        </View>
                    </View>
                    <View style={styles.bottomContainer}>
                        <Text style={styles.title}>{t('yourbudgetbuddy')}</Text>
                        <Text style={styles.desc}>{t('takecontrolofyour')}</Text>
                    </View>
                </>
                <>
                    <View style={styles.topContainer}>
                        <View style={styles.logoImageWrapper}>
                            <View style={styles.logoSpace} />
                            <View style={styles.imageView}>
                                <Image source={Image2} style={{ height: '100%', width: '100%' }} />
                            </View>
                        </View>
                        <View style={styles.logoView}>
                            <Text style={styles.logo}>WALLETUS</Text>
                        </View>
                    </View>
                    <View style={styles.bottomContainer}>
                        <Text style={styles.title}>{t('ultimateexpensetracker')}</Text>
                        <Text style={styles.desc}>{t('simplifyyourexpense')}</Text>
                    </View>
                </>
                <>
                    <View style={styles.topContainer}>
                        <View style={styles.logoImageWrapper}>
                            <View style={styles.logoSpace} />
                            <View style={styles.imageView}>
                                <Image source={Image3} style={{ height: '100%', width: '100%' }} />
                            </View>
                        </View>
                        <View style={styles.logoView}>
                            <Text style={styles.logo}>WALLETUS</Text>
                        </View>
                    </View>
                    <View style={styles.bottomContainer}>
                        <Text style={styles.title}>{t('plantrackandsave')}</Text>
                        <Text style={styles.desc}>{t('smartsaverisacomprehensive')}</Text>
                    </View>
                </>
            </Swiper>
            <View style={styles.buttonView}>
                <TouchableOpacity
                    onPress={() => navigation.navigate('SocialLoginScreen' as never)}
                    style={styles.simpleButton}>
                    <Text style={styles.simpleButtonText}>{t('skip')}</Text>
                </TouchableOpacity>
                <View style={{ flex: 1 }} />
                <TouchableOpacity
                    onPress={handleNextButton}
                    style={styles.button}>
                    <Text style={styles.buttonText}>{t('next')}</Text>
                    <View style={{ width: 10 }} />
                    <ArrowRight />
                </TouchableOpacity>
            </View>
            <SafeAreaView />
        </LinearGradient>
    )
}

const styles = StyleSheet.create({
    logo: {
        color: Colors.WHITE,
        transform: [{ rotate: '270deg' }],
        ...Fonts.bold25
    },
    topContainer: {
        flexDirection: 'row', height: '60%', width: '100%'
    },
    logoImageWrapper: {
        height: '100%',
        flexDirection: 'row',
        justifyContent: 'center'
    },
    logoView: {
        height: '100%',
        width: '100%',
        position: 'absolute',
        alignItems: 'flex-start',
        justifyContent: 'center',
        marginLeft: '-10%'
    },
    logoSpace: {
        height: '100%',
        width: '12%',
        alignItems: 'center',
        justifyContent: 'center'
    },
    imageView: {
        height: '100%',
        width: '88%',
        backgroundColor: 'grey',
        borderBottomLeftRadius: 40,
        overflow: 'hidden'
    },
    bottomContainer: {
        padding: 16,
        width: '100%',
        alignItems: 'center'
    },
    title: {
        color: Colors.WHITE,
        textAlign: 'center',
        ...Fonts.bold30
    },
    desc: {
        color: Colors.WHITE,
        textAlign: 'center',
        marginVertical: 10,
        ...Fonts.regular17
    },
    dot: {
        backgroundColor: Colors.WHITE + 50,
        height: 5,
        width: 20
    },
    buttonView: {
        flexDirection: 'row',
        padding: 16
    },
    simpleButton: {
        height: 50,
        borderRadius: 50,
        width: 143,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
    },
    simpleButtonText: {
        color: Colors.WHITE,
        ...Fonts.semiBold20
    },
    button: {
        height: 50,
        borderRadius: 50,
        width: 143,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: Colors.WHITE,
        marginRight: '5%',
        shadowColor: "#000",
        shadowOffset: {
            width: 0,
            height: 1,
        },
        shadowOpacity: 0.22,
        shadowRadius: 2.22,
        elevation: 3,
    },
    buttonText: {
        color: Colors.BLUE,
        ...Fonts.semiBold20
    }
})