import React, { useState } from "react";
import { SafeAreaView, ScrollView, StyleSheet, Text, TextInput, TouchableOpacity, View } from "react-native";
import DrawerIcon from "../../Assets/svg/drawer.svg";
import CalendarIcon from "../../Assets/svg/calendar.svg";
import DownArrowIcon from "../../Assets/svg/down-arrow.svg";
import DollarIcon from "../../Assets/svg/dollar.svg";
import TotalSpentIcon from "../../Assets/svg/total-spent.svg";
import RemainingIcon from "../../Assets/svg/remaining.svg";
import IconButton from "../../Components/IconButton";
import CustomAppBar from "../../Components/CustomAppBar";
import SpaceStyles from "../styles/SpaceStyles";
import CommonStyles from "../styles/CommonStyles";
import RestaurantIcon from "../../Assets/svg/restaurant.svg";
import HospitalIcon from "../../Assets/svg/hospital.svg";
import GroceriesIcon from "../../Assets/svg/groceries.svg";
import GiftIcon from "../../Assets/svg/gift.svg";
import CloseIcon from "../../Assets/svg/close.svg";
import ShoppingIcon from "../../Assets/svg/shopping.svg";
import { useTranslation } from "react-i18next";
import BudgetCategories from "../../Components/BudgetCategories";
import NotBudgetCategories from "../../Components/NotBudgetCategories";
import Modal from "react-native-modal";
import CustomButton from "../../Components/CustomButton";
import { useNavigation } from "@react-navigation/native";
import { useDrawerStatus } from "@react-navigation/drawer";
import SelectAccountModal from "../../Components/SelectAccountModal";
import CalendarModal from "../../Components/CalendarModal";
import Loader from "../../Constants/loader";
import { Colors, Fonts } from "../../Constants";

export default function BudgetScreen() {
    const { t } = useTranslation();
    const navigation = useNavigation();
    const [isVisible, setIsVisible] = useState(false)
    const [loading, setLoading] = useState(false)
    const [accountVisible, setAccountVisible] = useState(false)
    const [isEdit, setIsEdit] = useState(false)
    const isDrawerOpen = useDrawerStatus() === 'open';
    const [showCalendars, setShowCalendars] = useState(false);
    const [budgetData, setBudgetData] = useState();
    const [amount, setAmount] = useState('0')
    const [selectedBudgetCategory, setSelectedBudgetCategory] = useState();
    const [selectedNotBudgetCategory, setSelectedNotBudgetCategory] = useState();
    const [selectedDate, setSelectedDate] = useState({});

    const AppBar = () => {
        return (
            <CustomAppBar>
                <IconButton onPress={() => isDrawerOpen ? navigation.closeDrawer() : navigation.openDrawer()}>
                    <DrawerIcon height={26} width={26} />
                </IconButton>
                <View style={CommonStyles.header}>
                    <TouchableOpacity
                        onPress={() => setAccountVisible(true)}
                        style={CommonStyles.headerTitleWrapper}>
                        <DollarIcon height={16} width={16} />
                        <Text style={CommonStyles.headerTitle}>{t('total')}</Text>
                        <DownArrowIcon height={12} width={12} />
                    </TouchableOpacity>
                    <Text style={CommonStyles.headerSubTitle}>{'\$1200'}</Text>
                </View>
                <IconButton onPress={() => setShowCalendars(true)}>
                    <CalendarIcon height={26} width={26} />
                </IconButton>
            </CustomAppBar>
        )
    }

    return (
        <View style={CommonStyles.mainContainer}>
            <Loader loading={loading} />
            <SafeAreaView style={{ backgroundColor: Colors.LIGHT_BLUE }} />
            <AppBar />
            <ScrollView>
                <View style={[SpaceStyles.flexRow, { justifyContent: 'space-evenly' }]}>
                    <View style={[SpaceStyles.alignSpaceCenter, CommonStyles.shadow, styles.topContainer]}>
                        <View style={CommonStyles.budgetTopRound}>
                            <DollarIcon height={28} width={28} />
                        </View>
                        <Text style={{ color: Colors.GREY, ...Fonts.regular15 }}>{t('totalbudget')}</Text>
                        <Text style={{ color: Colors.BLACK, ...Fonts.semiBold16 }}>$24</Text>
                    </View>
                    <View style={[SpaceStyles.alignSpaceCenter, CommonStyles.shadow, styles.topContainer]}>
                        <View style={CommonStyles.budgetTopRound}>
                            <TotalSpentIcon height={28} width={28} />
                        </View>
                        <Text style={{ color: Colors.GREY, ...Fonts.regular15 }}>{t('totalspent')}</Text>
                        <Text style={{ color: Colors.BLACK, ...Fonts.semiBold16 }}>$10</Text>
                    </View>
                    <View style={[SpaceStyles.alignSpaceCenter, CommonStyles.shadow, styles.topContainer]}>
                        <View style={CommonStyles.budgetTopRound}>
                            <RemainingIcon height={28} width={28} />
                        </View>
                        <Text style={{ color: Colors.GREY, ...Fonts.regular15 }}>{t('remaining')}</Text>
                        <Text style={{ color: Colors.BLACK, ...Fonts.semiBold16 }}>$20</Text>
                    </View>
                </View>

                <View style={{ alignItems: 'center' }}>
                    <Text style={{ color: Colors.BLACK, ...Fonts.semiBold14 }}>{t('today')}</Text>
                    <View style={[styles.progress, { width: '75%' }]} />
                    <Text style={{ color: Colors.BLACK, ...Fonts.medium14 }}>20% {t('used')}</Text>
                </View>

                <View style={{ padding: 16 }}>
                    <Text style={{ color: Colors.BLACK, ...Fonts.semiBold18 }}>{t('budgetedcategories')}</Text>
                    <BudgetCategories
                        icon={<RestaurantIcon />}
                        iconBackgroundColor={'#FF9900'}
                        title={t('restaurants')}
                        subTitle={'Remaining: $12'}
                        used={'0'}
                        limit={'12'}
                        spent={'0'}
                        remaining={'12'}
                        editBudget={() => { setIsEdit(true), setIsVisible(true) }}
                        viewTransaction={() => navigation.navigate('TransactionsScreen' as never)}
                    />
                    <BudgetCategories
                        icon={<HospitalIcon />}
                        iconBackgroundColor={'#6CA12B'}
                        title={'Hospital'}
                        subTitle={'Remaining: $12'}
                        used={'0'}
                        limit={'12'}
                        spent={'0'}
                        remaining={'12'}
                        editBudget={() => { setIsEdit(true), setIsVisible(true) }}
                        viewTransaction={() => navigation.navigate('TransactionsScreen' as never)}
                    />
                </View>

                <View style={{ padding: 16, paddingTop: 0 }}>
                    <Text style={{ color: Colors.BLACK, ...Fonts.semiBold18 }}>{t('notbudgetedcategories')}</Text>
                    <NotBudgetCategories
                        icon={<GroceriesIcon />}
                        iconBackgroundColor={'#E8504D'}
                        title={'Groceries'}
                        spent={'0'}
                        setLimit={() => { setIsEdit(false), setIsVisible(true) }}
                    />
                    <NotBudgetCategories
                        icon={<GiftIcon />}
                        iconBackgroundColor={'#293377'}
                        title={'Gifts'}
                        spent={'0'}
                        setLimit={() => { setIsEdit(false), setIsVisible(true) }}
                    />
                    <NotBudgetCategories
                        icon={<ShoppingIcon />}
                        iconBackgroundColor={'#B16668'}
                        title={'Shopping'}
                        spent={'0'}
                        setLimit={() => { setIsEdit(false), setIsVisible(true) }}
                    />
                </View>
            </ScrollView>

            <SelectAccountModal isVisible={accountVisible} setIsVisible={setAccountVisible} />

            <CalendarModal showCalendars={showCalendars} setShowCalendars={setShowCalendars} setSelectedDate={setSelectedDate} />

            <Modal
                style={{ margin: 0 }}
                animationIn='zoomIn'
                animationOut='zoomOut'
                backdropTransitionOutTiming={0}
                backdropTransitionInTiming={0}
                onBackdropPress={() => setIsVisible(false)}
                onBackButtonPress={() => setIsVisible(false)}
                avoidKeyboard={true}
                isVisible={isVisible}>
                <View style={CommonStyles.modalMainView}>
                    <View style={CommonStyles.modalCell}>
                        <Text style={{ color: Colors.BLACK, ...Fonts.semiBold18 }}>{isEdit ? t('editbudget') : t('setbudget')}</Text>
                        <TouchableOpacity onPress={() => setIsVisible(false)}>
                            <CloseIcon />
                        </TouchableOpacity>
                    </View>
                    <View style={CommonStyles.divider} />
                    <View style={{ padding: 20, width: '100%' }}>
                        <View style={SpaceStyles.flexRow}>
                        <View style={[CommonStyles.itemIcon, { backgroundColor: '#FF9900', marginRight: 10 }]}>
                                <RestaurantIcon />
                            </View>
                            <Text style={{ color: Colors.BLACK, ...Fonts.semiBold16 }}>Restaurants</Text>
                        </View>
                        <TextInput
                            keyboardType="decimal-pad"
                            returnKeyType="done"
                            value={amount}
                            onChangeText={(t) => setAmount(t)}
                            style={styles.modalTextInput}
                        />
                        <View style={styles.modalButton}>
                            {isEdit && <>
                                <CustomButton
                                    onPress={() => { setIsVisible(false) }}
                                    colors={[Colors.RED, Colors.RED]}
                                    style={styles.modalButtonSize}>
                                    <Text style={styles.modalButtonText}>{t('delete')}</Text>
                                </CustomButton>
                                <View style={{ width: 10 }} />
                            </>}
                            <CustomButton
                                onPress={() => { }}
                                style={styles.modalButtonSize}>
                                <Text style={styles.modalButtonText}>{t('save')}</Text>
                            </CustomButton>
                            <View style={{ width: 10 }} />
                            <CustomButton
                                onPress={() => setIsVisible(false)}
                                style={styles.modalButtonSize}>
                                <Text style={styles.modalButtonText}>{t('cancel')}</Text>
                            </CustomButton>
                        </View>
                    </View>
                </View>
            </Modal>
        </View>
    )
}

const styles = StyleSheet.create({
    mainContainer: {
        flex: 1
    },
    topContainer: {
        backgroundColor: Colors.WHITE,
        width: '28%',
        borderRadius: 20,
        paddingHorizontal: 2,
        paddingVertical: 6,
        marginVertical: 16
    },
    progress: {
        height: 15,
        marginVertical: 10,
        borderRadius: 30,
        backgroundColor: Colors.LIGHT_BLUE
    },
    modalTextInput: {
        marginVertical: 20,
        paddingHorizontal: 20,
        height: 50,
        borderWidth: 1,
        borderColor: Colors.LIGHT_GREY,
        borderRadius: 20,
        color: Colors.BLACK
    },
    modalButton: {
        flexDirection: 'row', 
        justifyContent: 'center'
    },
    modalButtonSize: {
        height: 30, width: 90
    },
    modalButtonText: {
        color: Colors.WHITE,
        ...Fonts.medium14
    }
})