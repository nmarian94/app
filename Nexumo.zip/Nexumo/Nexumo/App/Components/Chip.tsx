import React from "react";
import { StyleSheet, Text, TouchableOpacity, View } from "react-native";
import { Colors, Fonts } from "../Constants";

const Chip = ({ key, fullColor, iconColor, children, label, labelStyle, style, onPress }: any) => {
    return (
        <TouchableOpacity key={key} onPress={onPress} style={[styles.mainContainer, style, { backgroundColor: fullColor }]}>
            <View style={[styles.iconView, { backgroundColor: iconColor }]}>
                {children}
            </View>
            <Text style={[styles.text, labelStyle]}>{label}</Text>
        </TouchableOpacity>
    )
}

export default Chip;

const styles = StyleSheet.create({
    mainContainer: {
        margin: 5,
        flexDirection: 'row',
        alignItems: 'center',
        borderRadius: 20,
        borderWidth: 1,
        borderColor: Colors.LIGHT_GREY,
        alignSelf: 'flex-start'
    },
    iconView: {
        height: 30,
        width: 30,
        borderRadius: 20,
        alignItems: 'center',
        justifyContent: 'center',
    },
    text: {
        color: Colors.BLACK,
        marginLeft: 5,
        marginRight: 10,
        textTransform: 'capitalize',
        ...Fonts.semiBold14
    }
})