import React from "react";
import { KeyboardTypeOptions, StyleProp, StyleSheet, Text, TextInput, TouchableOpacity, View, ViewStyle } from "react-native";
import EyeOpen from "../Assets/svg/eye-open.svg";
import { Colors, Fonts } from "../Constants";

interface CustomTextInputProps {
    autoCapitalize?: 'none' | 'sentences' | 'words' | 'characters' | undefined;
    keyboardType?: KeyboardTypeOptions | undefined;
    value?: string | undefined;
    onChangeText?: ((text: string) => void) | undefined;
    showIcon?: boolean, 
    secureTextEntry?: boolean | undefined;
    label?: string, 
    placeholder?: string,
    style?: StyleProp<ViewStyle>;
    onPress?: () => void;
}

const CustomTextInput: React.FC<CustomTextInputProps> = ({ autoCapitalize, keyboardType, value, onChangeText, showIcon, secureTextEntry, label, placeholder, style, onPress }) => {
    return (
        <View style={[styles.mainContainer, style]}>
            {label && <View style={styles.labelContainer}>
                <Text style={styles.labelStyle}>{label}</Text>
            </View>}
            <TextInput
                autoCapitalize={autoCapitalize}
                keyboardType={keyboardType}
                value={value}
                onChangeText={onChangeText}
                secureTextEntry={secureTextEntry}
                placeholder={placeholder}
                placeholderTextColor={Colors.GREY}
                returnKeyType="done"
                style={styles.inputContainer} />
            {showIcon && <View style={{ position: 'absolute', right: 16, top: 18 }}>
                <TouchableOpacity onPress={onPress}>
                    <EyeOpen />
                </TouchableOpacity>
            </View>}
        </View>
    )
}

export default CustomTextInput;

const styles = StyleSheet.create({
    mainContainer: {
        height: 56,
    },
    labelContainer: {
        backgroundColor: "white", // Same color as background
        alignSelf: "flex-start", // Have View be same width as Text inside
        paddingHorizontal: 6, // Amount of spacing between border and first/last letter
        marginStart: 16, // How far right do you want the label to start
        zIndex: 1, // Label must overlap border
        elevation: 1, // Needed for android
        shadowColor: "white", // Same as background color because elevation: 1 creates a shadow that we don't want
        position: "absolute", // Needed to be able to precisely overlap label with border
        top: -10, // Vertical position of label. Eyeball it to see where label intersects border.
    },
    labelStyle: {
        color: Colors.BLUE,
        ...Fonts.semiBold15
    },
    inputContainer: {
        height: 56,
        justifyContent: 'center',
        borderWidth: 1, // Create border
        borderColor: Colors.LIGHT_GREY,
        borderRadius: 8, // Not needed. Just make it look nicer.
        padding: 8, // Also used to make it look nicer
        zIndex: 0, // Ensure border has z-index of 0
        color: Colors.BLACK,
        ...Fonts.regular16
    },
})