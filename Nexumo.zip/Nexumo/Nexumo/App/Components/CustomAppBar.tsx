import React from "react";
import { StyleSheet } from "react-native";
import LinearGradient from "react-native-linear-gradient";
import { Colors } from "../Constants";

const CustomAppBar = ({children}: any) => {
    return (
        <LinearGradient
            colors={[Colors.BLUE, Colors.LIGHT_BLUE]}
            start={{ x: 0, y: 1 }} end={{ x: 0, y: 0 }}
            style={styles.container}>
            {children}
        </LinearGradient>
    )
}

export default CustomAppBar;

const styles = StyleSheet.create({
    container: {
        flexDirection: 'row', height: 60, alignItems: 'center'
    }
})