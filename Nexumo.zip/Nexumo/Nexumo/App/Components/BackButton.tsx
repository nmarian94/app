import React from "react";
import { StyleProp, StyleSheet, TouchableOpacity, ViewStyle } from "react-native";
import BackIcon from "../Assets/svg/back-arrow.svg";

interface BackButtonProps {
    onPress?: () => void;
    style?: StyleProp<ViewStyle>;
}

export default function BackButton({ onPress, style }: BackButtonProps) {
    return (
        <TouchableOpacity
            onPress={onPress}
            style={[styles.button, style]}>
            <BackIcon />
        </TouchableOpacity>
    )
}

const styles = StyleSheet.create({
    button: {
        padding: 16,
        width: 24
    }
})