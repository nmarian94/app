import React from "react";
import { StyleProp, StyleSheet, TouchableOpacity, ViewStyle } from "react-native";
import LinearGradient from "react-native-linear-gradient";
import { Colors } from "../Constants";

interface CustomButtonProps {
    onPress?: () => void;
    style?: StyleProp<ViewStyle>;
    children?: any;
    colors?: (string | number)[];
}

const CustomButton: React.FC<CustomButtonProps> = ({ onPress, style, children, colors = [Colors.BLUE, Colors.LIGHT_BLUE] }) => {
    return (
        <LinearGradient
            colors={colors}
            start={{ x: 0, y: 1 }} end={{ x: 0, y: 0 }}
            style={[styles.mainContainer, style]}>
            <TouchableOpacity onPress={onPress} style={[styles.mainContainer, styles.button]}>
                {children}
            </TouchableOpacity>
        </LinearGradient>
    )
}

export default CustomButton;

const styles = StyleSheet.create({
    mainContainer: {
        height: 50,
        borderWidth: 1,
        borderColor: 'transparent',
        borderRadius: 50,
        alignItems: 'center',
        justifyContent: 'center'
    },
    button: {
        width: '100%',
        flexDirection: 'row',
        alignItems: 'center'
    }
})