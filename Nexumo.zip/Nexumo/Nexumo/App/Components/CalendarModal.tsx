import React, { useEffect, useState } from "react";
import { StyleSheet, Text, TouchableOpacity, View, Alert } from "react-native";
import Modal from "react-native-modal";
import CloseIcon from "../Assets/svg/close.svg";
import { Calendar } from "react-native-calendars";
import CommonStyles from "../Screens/styles/CommonStyles";
import { useTranslation } from "react-i18next";
import SpaceStyles from "../Screens/styles/SpaceStyles";
import moment from "moment";
import { Colors, Fonts } from "../Constants";

const CalendarModal = ({ showCalendars, setShowCalendars, setSelectedDate }: any) => {
    const { t } = useTranslation();
    // const [markedDates, setMarkedDates] = useState({});
    const [isStartDatePicked, setIsStartDatePicked] = useState(false);
    const [isEndDatePicked, setIsEndDatePicked] = useState(false);
    const [startDate, setStartDate] = useState('');
    const [markedDates, setMarkedDates] = useState({});
    const [startdate, setStartdate] = useState('');
    const [enddate, setEnddate] = useState('');

    useEffect(() => {
        if (markedDates.length == 0) {
            return;
        }

        const markedDateKeys = Object.keys(markedDates);
        setStartdate(markedDateKeys.length > 0 ? markedDateKeys[0] : null);
        setEnddate(markedDateKeys.length > 0 ? markedDateKeys[markedDateKeys.length - 1] : null);
    }, [markedDates])

    useEffect(() => {
        // Set default start date to the first day of the month
        const firstDayOfMonth = moment(Date.now()).startOf('month').format('YYYY-MM-DD');

        // Set default end date to the last day of the month
        const lastDayOfMonth = moment(Date.now()).endOf('month').format('YYYY-MM-DD');

        const newMarkedDates = {
            [firstDayOfMonth]: {
                startingDay: true,
                color: Colors.WHITE,
                textColor: Colors.BLUE,
            },
        };

        const selectedStartDate = moment(firstDayOfMonth);
        const selectedEndDate = moment(lastDayOfMonth);
        const range = selectedEndDate.diff(selectedStartDate, 'days');

        for (let i = 1; i <= range; i++) {
            let tempDate = moment(selectedStartDate).add(i, 'day').format('YYYY-MM-DD');
            if (i < range) {
                newMarkedDates[tempDate] = { color: Colors.WHITE, textColor: Colors.BLUE };
            } else {
                newMarkedDates[tempDate] = { endingDay: true, color: Colors.WHITE, textColor: Colors.BLUE };
            }
        }

        setMarkedDates(newMarkedDates);
        setSelectedDate(newMarkedDates);
    }, [])

    const onDayPress = (day) => {
        if (!isStartDatePicked) {
            const newMarkedDates = {
                [day.dateString]: {
                    startingDay: true,
                    color: Colors.WHITE,
                    textColor: Colors.BLUE,
                },
            };
            setMarkedDates(newMarkedDates);
            setIsStartDatePicked(true);
            setIsEndDatePicked(false);
            setStartDate(day.dateString);
        } else {
            const newMarkedDates = { ...markedDates };
            const selectedStartDate = moment(startDate);
            const selectedEndDate = moment(day.dateString);
            const range = selectedEndDate.diff(selectedStartDate, 'days');

            if (range > 0) {
                for (let i = 1; i <= range; i++) {
                    let tempDate = moment(selectedStartDate).add(i, 'day').format('YYYY-MM-DD');
                    if (i < range) {
                        newMarkedDates[tempDate] = { color: Colors.WHITE, textColor: Colors.BLUE };
                    } else {
                        newMarkedDates[tempDate] = { endingDay: true, color: Colors.WHITE, textColor: Colors.BLUE };
                    }
                }

                setMarkedDates(newMarkedDates);
                setIsStartDatePicked(false);
                setIsEndDatePicked(true);
                setStartDate('');
            } else {
                Alert.alert('Select an upcoming date!');
            }
        }
    };

    return (
        <Modal
            style={{ margin: 0 }}
            animationIn='zoomIn'
            animationOut='zoomOut'
            backdropTransitionOutTiming={0}
            backdropTransitionInTiming={0}
            onBackdropPress={() => setShowCalendars(false)}
            onBackButtonPress={() => setShowCalendars(false)}
            avoidKeyboard={true}
            isVisible={showCalendars}>
            <View style={CommonStyles.modalMainView}>
                <View style={CommonStyles.modalCell}>
                    <Text style={styles.modalTitle}>{t('selectperiod')}</Text>
                    <TouchableOpacity onPress={() => setShowCalendars(false)}>
                        <CloseIcon />
                    </TouchableOpacity>
                </View>
                <View style={CommonStyles.divider} />

                <View style={[SpaceStyles.flexRow, { padding: 20, paddingBottom: 0 }]}>
                    <Text style={{ flex: 1, color: Colors.BLACK, ...Fonts.medium15 }}>
                        {`From ${moment(startdate).format('MMM DD')} to ${moment(enddate).format('MMM DD, YYYY')}`}
                    </Text>
                    <View style={styles.checkBox} />
                    <Text style={{ color: Colors.BLACK, ...Fonts.medium15 }}>All time</Text>
                </View>

                <View style={CommonStyles.calenderContainer}>
                    <Calendar
                        markingType={'period'}
                        theme={{
                            backgroundColor: Colors.BLUE,
                            calendarBackground: Colors.BLUE,
                            dayTextColor: Colors.WHITE,
                            textDayFontSize: 15,
                            textDayFontWeight: '600',
                            monthTextColor: Colors.WHITE,
                            textMonthFontWeight: '600',
                            textSectionTitleColor: Colors.WHITE,
                            textDayHeaderFontWeight: '600',
                            selectedDayTextColor: Colors.WHITE,
                            arrowColor: Colors.BLUE
                        }}
                        disableArrowLeft={false}
                        disableArrowRight={false}
                        markedDates={markedDates}
                        onDayPress={onDayPress}
                        style={{ backgroundColor: Colors.BLUE, borderRadius: 20, marginHorizontal: 20 }}
                    />
                    <View style={CommonStyles.calendarButtonView}>
                        <TouchableOpacity
                            onPress={() => { setShowCalendars(false), setMarkedDates({}), setStartDate(''), setEnddate(''), setIsStartDatePicked(false), setIsEndDatePicked(false) }}
                            style={CommonStyles.calendarButton}>
                            <Text style={{ color: Colors.WHITE, ...Fonts.semiBold15 }}>Cancel</Text>
                        </TouchableOpacity>
                        <TouchableOpacity
                            onPress={() => { setShowCalendars(false), setSelectedDate(markedDates) }}
                            style={CommonStyles.calendarButton}>
                            <Text style={{ color: Colors.WHITE, ...Fonts.semiBold15 }}>Ok</Text>
                        </TouchableOpacity>
                    </View>
                </View>
            </View>
        </Modal>
    )
}

export default CalendarModal

const styles = StyleSheet.create({
    modalTitle: {
        color: Colors.BLACK, ...Fonts.semiBold18
    },
    checkBox: {
        height: 18, width: 18, marginRight: 5, borderWidth: 2, borderColor: Colors.BLUE, borderRadius: 2
    },
})