import React, { Key, useState } from "react";
import { StyleSheet, Text, TouchableOpacity, View } from "react-native";
import CommonStyles from "../Screens/styles/CommonStyles";
import SpaceStyles from "../Screens/styles/SpaceStyles";
import DownArrowBlack from "../Assets/svg/down-arrow-black.svg";
import CustomButton from "./CustomButton";
import { useTranslation } from "react-i18next";
import { Colors, Fonts } from "../Constants";

interface BudgetCategoriesProps {
    key?: Key | null | undefined;
    icon?: any, 
    iconBackgroundColor?: string, 
    title?: string; 
    subTitle?: string; 
    used?: string;
    limit?: string, 
    spent?: string, 
    remaining?: string,
    editBudget?: () => void; 
    viewTransaction?: () => void;
}

const BudgetCategories: React.FC<BudgetCategoriesProps> = ({ key, icon, iconBackgroundColor, title, subTitle, used, limit, spent, remaining, editBudget, viewTransaction }) => {
    const { t } = useTranslation();
    const [isShow, setIsShow] = useState(false)

    return (
        <TouchableOpacity
            key={key}
            onPress={() => setIsShow(!isShow)}
            style={styles.button}>
            <View style={styles.budgetDataStyle}>
                <View style={[CommonStyles.itemIcon, { backgroundColor: iconBackgroundColor }]}>
                    {icon}
                </View>
                <View style={{ flex: 1 }}>
                    <View style={SpaceStyles.flexRow}>
                        <Text style={styles.dataLabel}>{title}</Text>
                        <DownArrowBlack />
                    </View>
                    <Text style={styles.dataSubLabel}>{subTitle}</Text>
                </View>
                <View style={styles.budgetUsed}>
                    <Text style={{ color: Colors.BLUE, ...Fonts.medium12 }}>{used}% {t('used')}</Text>
                </View>
            </View>
            {isShow && <>
                <View style={[SpaceStyles.flexRow, { paddingTop: 10, paddingHorizontal: 20, justifyContent: 'space-evenly' }]}>
                    <View style={{ alignItems: 'center' }}>
                        <Text style={{ color: Colors.BLUE, ...Fonts.medium14 }}>{t('limit')}</Text>
                        <Text style={{ color: Colors.BLUE, ...Fonts.bold16 }}>{limit}</Text>
                    </View>
                    <View style={{ alignItems: 'center' }}>
                        <Text style={{ color: Colors.BLUE, ...Fonts.medium14 }}>{t('spent')}</Text>
                        <Text style={{ color: Colors.BLUE, ...Fonts.bold16 }}>{spent}</Text>
                    </View>
                    <View style={{ alignItems: 'center' }}>
                        <Text style={{ color: Colors.BLUE, ...Fonts.medium14 }}>{t('remaining')}</Text>
                        <Text style={{ color: Colors.BLUE, ...Fonts.bold16 }}>{remaining}</Text>
                    </View>
                </View>
                <View style={styles.budgetButton}>
                    <CustomButton
                        onPress={editBudget}
                        style={styles.budgetButtonSize}>
                        <Text style={styles.budgetButtonText}>{t('editbudget')}</Text>
                    </CustomButton>
                    <View style={{ width: 10 }} />
                    <CustomButton
                        onPress={viewTransaction}
                        style={styles.budgetButtonSize}>
                        <Text style={styles.budgetButtonText}>{t('viewtransaction')}</Text>
                    </CustomButton>
                </View>
            </>}
        </TouchableOpacity>
    )
}

export default BudgetCategories;

const styles = StyleSheet.create({
    button: {
        marginTop: 10,
        padding: 10,
        borderRadius: 20,
        backgroundColor: Colors.WHITE,
        shadowColor: "#000",
        shadowOffset: {
            width: 0,
            height: 1,
        },
        shadowOpacity: 0.20,
        shadowRadius: 1.41,
        elevation: 2,
    },
    budgetDataStyle: {
        flexDirection: 'row',
        alignItems: 'center',
    },
    dataLabel: {
        paddingHorizontal: 10,
        color: Colors.BLACK,
        ...Fonts.semiBold16
    },
    dataSubLabel: {
        color: Colors.GREY, paddingLeft: 10, ...Fonts.regular14
    },
    budgetUsed: {
        height: 25, borderWidth: 2, borderColor: Colors.BLUE, width: 80, borderRadius: 50, alignItems: 'center', justifyContent: 'center'
    },
    setLimitButton: {
        height: 30, width: 100, borderRadius: 50, alignItems: 'center', justifyContent: 'center'
    },
    budgetButton: {
        flexDirection: 'row', padding: 10, justifyContent: 'center'
    },
    budgetButtonSize: {
        height: 30, width: 148
    },
    budgetButtonText: {
        color: Colors.WHITE, ...Fonts.medium14
    }
})