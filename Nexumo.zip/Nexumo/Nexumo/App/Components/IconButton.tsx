import React from "react";
import { DimensionValue, StyleProp, StyleSheet, TouchableOpacity, ViewStyle } from "react-native";

interface IconButtonProps {
    onPress?: () => void;
    size?: DimensionValue | undefined;
    style?: StyleProp<ViewStyle>;
    children?: any;
}

const IconButton: React.FC<IconButtonProps> = ({ onPress, size, style, children }: any) => {
    return (
        <TouchableOpacity onPress={onPress} style={[styles.mainContainer, { height: size, width: size }, style]}>
            {children}
        </TouchableOpacity>
    )
}

export default IconButton;

const styles = StyleSheet.create({
    mainContainer: {
        padding: 16,
        alignItems: 'center',
        justifyContent: 'center'
    },
})