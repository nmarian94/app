import React from "react";
import Modal from "react-native-modal";
import CommonStyles from "../Screens/styles/CommonStyles";
import { StyleSheet, Text, TouchableOpacity, View } from "react-native";
import CloseIcon from "../Assets/svg/close.svg";
import TotalDollarIcon from "../Assets/svg/total-dollar.svg";
import MainDollarIcon from "../Assets/svg/main-dollar.svg";
import CashDollarIcon from "../Assets/svg/cash-dollar.svg";
import RadioSelectedIcon from "../Assets/svg/radio-selected.svg";
import RadioUnSelectedIcon from "../Assets/svg/radio-unselected.svg";
import SpaceStyles from "../Screens/styles/SpaceStyles";
import { useTranslation } from "react-i18next";
import { Colors, Fonts } from "../Constants";

const SelectAccountModal = ({ isVisible, setIsVisible }: any) => {
    const { t } = useTranslation();

    return (
        <Modal
            style={{ margin: 0 }}
            animationIn='zoomIn'
            animationOut='zoomOut'
            backdropTransitionOutTiming={0}
            backdropTransitionInTiming={0}
            onBackdropPress={() => setIsVisible(false)}
            onBackButtonPress={() => setIsVisible(false)}
            avoidKeyboard={true}
            isVisible={isVisible}>
            <View style={CommonStyles.modalMainView}>
                <View style={CommonStyles.modalCell}>
                    <Text style={styles.modalTitle}>{t('selectaccount')}</Text>
                    <TouchableOpacity onPress={() => setIsVisible(false)}>
                        <CloseIcon />
                    </TouchableOpacity>
                </View>
                <View style={CommonStyles.divider} />
                <View style={CommonStyles.modalCell}>
                    <View>
                        <View style={SpaceStyles.flexRow}>
                            <TotalDollarIcon />
                            <Text style={[styles.modalTitle, { marginLeft: 10 }]}>{t('total')}</Text>
                        </View>
                        <Text style={{ color: Colors.BLACK, ...Fonts.regular16 }}>$10,000</Text>
                    </View>
                    <RadioSelectedIcon />
                </View>
                <View style={CommonStyles.divider} />
                <View style={CommonStyles.modalCell}>
                    <View>
                        <View style={SpaceStyles.flexRow}>
                            <MainDollarIcon />
                            <Text style={[styles.modalTitle, { marginLeft: 10 }]}>{t('main')}</Text>
                        </View>
                        <Text style={{ color: Colors.BLACK, ...Fonts.regular16 }}>$5,000</Text>
                    </View>
                    <RadioUnSelectedIcon />
                </View>
                <View style={CommonStyles.divider} />
                <View style={CommonStyles.modalCell}>
                    <View>
                        <View style={SpaceStyles.flexRow}>
                            <CashDollarIcon />
                            <Text style={[styles.modalTitle, { marginLeft: 10 }]}>Cash</Text>
                        </View>
                        <Text style={{ color: Colors.BLACK, ...Fonts.regular16 }}>$300</Text>
                    </View>
                    <RadioUnSelectedIcon />
                </View>
            </View>
        </Modal>
    )
}

export default SelectAccountModal;

const styles = StyleSheet.create({
    modalTitle: {
        color: Colors.BLACK,
        ...Fonts.semiBold18
    },
})