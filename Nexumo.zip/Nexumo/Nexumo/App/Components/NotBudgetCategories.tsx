import React from "react";
import { StyleSheet, Text, TouchableOpacity, View } from "react-native";
import CommonStyles from "../Screens/styles/CommonStyles";
import { useTranslation } from "react-i18next";
import { Colors, Fonts } from "../Constants";

interface NotBudgetCategoriesProps {
    icon?: any, 
    iconBackgroundColor?: string, 
    title?: string; 
    spent?: string, 
    setLimit?: () => void; 
}

const NotBudgetCategories:  React.FC<NotBudgetCategoriesProps> = ({ icon, iconBackgroundColor, title, spent, setLimit }) => {
    const { t } = useTranslation();
    return (
        <View style={styles.budgetDataStyle}>
            <View style={[CommonStyles.itemIcon, { backgroundColor: iconBackgroundColor }]}>
                {icon}
            </View>
            <View style={{ flex: 1 }}>
                <Text style={styles.dataLabel}>{title}</Text>
                <Text style={styles.dataSubLabel}>{t('spent')}: {spent}</Text>
            </View>
            <TouchableOpacity
                onPress={setLimit}
                style={styles.setLimitButton}>
                <Text style={{ color: Colors.BLACK, ...Fonts.medium12 }}>{t('setlimit')}</Text>
            </TouchableOpacity>
        </View>
    )
}

export default NotBudgetCategories;

const styles = StyleSheet.create({
    budgetDataStyle: {
        flexDirection: 'row',
        alignItems: 'center',
        paddingVertical: 10,
        borderBottomWidth: 1,
        borderBottomColor: Colors.LIGHT_GREY
    },
    dataLabel: {
        paddingHorizontal: 10,
        color: Colors.BLACK,
        ...Fonts.semiBold16
    },
    dataSubLabel: {
        color: Colors.GREY, paddingLeft: 10, ...Fonts.regular14
    },
    setLimitButton: {
        height: 25, width: 80, backgroundColor: '#E6E6E6', marginRight: 10, borderRadius: 50, alignItems: 'center', justifyContent: 'center'
    },
})